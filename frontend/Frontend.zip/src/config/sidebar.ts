import { 
  Home, 
  Users, 
  Settings,
  ShieldCheck,
  BarChart, 
  Building2,
  ClipboardCheck,
  CreditCard,
  Package,
  Receipt,
  UserCog,
  FileSignature,
  Activity,
  Ticket,
  UserCircle,
  LayoutDashboard,
  IndianRupee,
  UserCheck,
  CalendarCheck,
  Award,
  PieChart,
  Shield,
  History,
  Smartphone,
  Bell,
  Mail,
  HardDrive,
  Database,
  Plug,
  Monitor,
  UserPlus,
  Upload,
  ImageIcon,
  MapPin,
  Network,
  ClipboardList,
  FileText,
  Inbox
} from 'lucide-react';
import type { ForwardRefExoticComponent, RefAttributes } from 'react';
import type { LucideProps } from 'lucide-react';

export type IconComponent = ForwardRefExoticComponent<Omit<LucideProps, "ref"> & RefAttributes<SVGSVGElement>>;

export interface SidebarMenuItem {
  id: string;
  title: string;
  icon?: IconComponent;
  path: string;
  children?: SidebarMenuItem[];
  roles?: string[];
  permissions?: string[];
  requiredFeature?: string;
  badgeValue?: string | number;
  category?: string;
  moduleKey?: string;
}

export const SIDEBAR_MENU: SidebarMenuItem[] = [
  // --- Standard / Shared Routes ---

  // --- Master Admin Routes ---
  {
    id: 'ma-dashboard',
    title: 'Master Dashboard',
    icon: Home,
    path: '/master-admin/dashboard',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-companies',
    title: 'Companies',
    icon: Building2,
    path: '/master-admin/companies',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-company-approval',
    title: 'Company Approval',
    icon: ClipboardCheck,
    path: '/master-admin/company-approvals',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-subscriptions',
    title: 'Subscriptions',
    icon: CreditCard,
    path: '/master-admin/subscriptions',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-plans',
    title: 'Plans',
    icon: Package,
    path: '/master-admin/plans',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-invoices',
    title: 'Invoices',
    icon: IndianRupee,
    path: '/master-admin/invoices',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-access-management',
    title: 'Access Management',
    icon: UserCog,
    path: '/master-admin/access-management',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-security',
    title: 'Security',
    icon: ShieldCheck,
    path: '/master-admin/security',
    roles: ['Master Admin'],
    children: [
      {
        id: 'ma-security-dashboard',
        title: 'Security Dashboard',
        path: '/master-admin/security',
        icon: LayoutDashboard,
      },
      {
        id: 'ma-login-sessions',
        title: 'Login Sessions',
        path: '/master-admin/security/sessions',
        icon: History,
      },
      {
        id: 'ma-trusted-devices',
        title: 'Trusted Devices',
        path: '/master-admin/security/devices',
        icon: Smartphone,
      }
    ]
  },
  {
    id: 'ma-activity-logs',
    title: 'Activity Logs',
    icon: Activity,
    path: '/master-admin/activity-logs',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-reports',
    title: 'Reports',
    icon: BarChart,
    path: '/master-admin/reports',
    roles: ['Master Admin'],
    children: [
      {
        id: "ma-reports-dashboard",
        title: "Reports Dashboard",
        path: "/master-admin/reports/dashboard",
        icon: LayoutDashboard,
      },

      {
        id: 'ma-reports-user-access',
        title: 'User & Access Reports',
        path: '/master-admin/reports/user-access',
        icon: Users,
      },
      {
        id: 'ma-reports-candidates',
        title: 'Candidate Reports',
        path: '/master-admin/reports/candidates',
        icon: UserCheck,
      },
      {
        id: 'ma-reports-exams',
        title: 'Exam Reports',
        path: '/master-admin/reports/exams',
        icon: ClipboardCheck,
      },
      {
        id: 'ma-reports-attendance',
        title: 'Attendance Reports',
        path: '/master-admin/reports/attendance',
        icon: CalendarCheck,
      },
      {
        id: 'ma-reports-results',
        title: 'Result & Merit Reports',
        path: '/master-admin/reports/results',
        icon: Award,
      },
      {
        id: 'ma-reports-financial',
        title: 'Financial Reports',
        path: '/master-admin/reports/financial',
        icon: PieChart,
      },
      {
        id: 'ma-reports-security',
        title: 'Security Reports',
        path: '/master-admin/reports/security',
        icon: ShieldCheck,
      }
    ]
  },
  {
    id: 'ma-system-settings',
    title: 'System Settings',
    icon: Settings,
    path: '/master-admin/settings/general',
    roles: ['Master Admin'],
  },
  {
    id: 'ma-support-tickets',
    title: 'Support Tickets',
    icon: Ticket,
    path: '/master-admin/support-tickets',
    roles: ['Master Admin'],
  },
  
  // --- Company Admin Routes ---
  {
    id: 'ca-dashboard',
    title: 'Dashboard',
    icon: Home,
    path: '/company/dashboard',
    roles: ['Company Admin'],
  },
  {
    id: 'ca-subscription',
    title: 'Subscription',
    icon: Award,
    path: '/company/subscription',
    roles: ['Company Admin'],
    children: [
      {
        id: 'ca-subscription-plans',
        title: 'Plans',
        path: '/company/subscription',
        icon: Award,
      },
      {
        id: 'ca-subscription-usage',
        title: 'Usage Plan',
        path: '/company/subscription/usage',
        icon: Activity,
      }
    ]
  },
  {
    id: 'ca-centers',
    title: 'Centers',
    icon: Building2,
    path: '/company/centers',
    roles: ['Company Admin'],
  },
  {
    id: 'ca-center-requests',
    title: 'Center Requests',
    icon: Inbox,
    path: '/company/centers/admin-requests',
    roles: ['Company Admin'],
  },
  {
    id: 'ca-staff',
    title: 'Generate Role Credentials',
    icon: Users,
    path: '/company/staff',
    roles: ['Company Admin'],
  },
  {
    id: 'ca-exam-manager-details',
    title: 'Exam Manager Details',
    icon: FileSignature,
    path: '/company/exam-manager-details',
    roles: ['Company Admin'],
    children: [
      {
        id: 'ca-show-exams',
        title: 'Show Exam',
        icon: FileSignature,
        path: '/company/exams',
        roles: ['Company Admin'],
      },
      {
        id: 'ca-subject-topics',
        title: 'Subject Topics',
        icon: FileSignature,
        path: '/company/subject-topics',
        roles: ['Company Admin'],
      }
    ]
  },
  {
    id: 'ca-paper-setter-group',
    title: 'Paper Setter',
    icon: UserPlus,
    path: '/company/paper-setter-group',
    roles: ['Company Admin'],
    children: [
      {
        id: 'ca-paper-setter-create',
        title: 'Paper Setter Create',
        icon: UserPlus,
        path: '/company/paper-setters',
        roles: ['Company Admin'],
      },
      {
        id: 'ca-final-papers',
        title: 'Final Papers',
        icon: FileSignature,
        path: '/company/final-papers',
        roles: ['Company Admin'],
      }
    ]
  },
  {
    id: 'ca-papers',
    title: 'Assign Exam to Center',
    icon: FileSignature,
    path: '/company/papers',
    roles: ['Company Admin'],
  },
  {
    id: 'ca-candidates',
    title: 'Assign Candidate to Center',
    icon: UserCircle,
    path: '/company/candidates',
    roles: ['Company Admin'],
  },

  {
    id: 'ca-results',
    title: 'Results',
    icon: Receipt,
    path: '/company/results',
    roles: ['Company Admin'],
  },
  {
    id: 'ca-live-monitoring',
    title: 'Live Monitoring',
    icon: Activity,
    path: '/company/live-monitoring',
    roles: ['Company Admin'],
    requiredFeature: 'liveMonitoring',
  },

  {
    id: 'ca-certificates',
    title: 'Certificates',
    icon: ClipboardCheck,
    path: '/company/certificates',
    roles: ['Company Admin'],
    requiredFeature: 'certificate',
  },
  {
    id: 'ca-reports',
    title: 'Reports & Analytics',
    icon: BarChart,
    path: '/company/reports',
    roles: ['Company Admin'],
    requiredFeature: 'reports',
  },
  {
    id: 'ca-centers-payment',
    title: 'Centers Payment',
    icon: IndianRupee,
    path: '/company/centers-payment',
    roles: ['Company Admin'],
  },
  {
    id: 'ca-profile',
    title: 'Company Profile',
    icon: Building2,
    path: '/company/profile',
    roles: ['Company Admin'],
  },
  {
    id: 'ca-settings',
    title: 'Settings',
    icon: Settings,
    path: '/company/settings',
    roles: ['Company Admin'],
  },
  // --- Center Manager Routes ---
  {
    id: 'cm-dashboard',
    title: 'Center Dashboard',
    icon: Home,
    path: '/dashboard/center-manager',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-admin-requests',
    title: 'Company Admin Requests',
    icon: Inbox,
    path: '/dashboard/center-manager/admin-requests',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-staff',
    title: 'Center Staff Add',
    icon: UserPlus,
    path: '/dashboard/center-manager/staff',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-labs',
    title: 'Center Lab Add',
    icon: Monitor,
    path: '/dashboard/center-manager/labs',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-assigned-exams',
    title: 'Assigned Exams',
    icon: Monitor,
    path: '/dashboard/center-manager/assigned-exams',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-infrastructure',
    title: 'Center Infrastructure',
    icon: Upload,
    path: '/dashboard/center-manager/infrastructure',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-center-photos',
    title: 'Center Photos',
    icon: ImageIcon,
    path: '/dashboard/center-manager/photos',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-center-location',
    title: 'Center Location',
    icon: MapPin,
    path: '/dashboard/center-manager/location',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-system-network',
    title: 'System Network',
    icon: Network,
    path: '/dashboard/center-manager/system-network',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-assign-exam-staff',
    title: 'Assign Exam Staff',
    icon: ClipboardList,
    path: '/dashboard/center-manager/assign-exam-staff',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-assign-candidate-seat-allocation',
    title: 'Assign Candidate Seat Allocation',
    icon: Users,
    path: '/dashboard/center-manager/assign-candidate-seat-allocation',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-assigned-candidate-attendance',
    title: 'Assigned Candidate Attendance',
    icon: Users,
    path: '/dashboard/center-manager/assigned-candidate-attendance',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-payments',
    title: 'Payments',
    icon: CreditCard,
    path: '/dashboard/center-manager/payments',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  {
    id: 'cm-audit-logs',
    title: 'Audit Logs',
    icon: Activity,
    path: '/dashboard/center-manager/audit-logs',
    roles: ['CENTER_MANAGER', 'Center Manager'],
  },
  // --- Exam Manager Routes ---
  {
    id: 'em-dashboard',
    title: 'Exam Dashboard',
    icon: Home,
    path: '/exam-manager/dashboard',
    roles: ['EXAM_MANAGER', 'Exam Manager'],
  },
  {
    id: 'em-exams',
    title: 'Exams',
    icon: ClipboardCheck,
    path: '/exam-manager/exams',
    roles: ['EXAM_MANAGER', 'Exam Manager'],
  },
  {
    id: 'em-topics',
    title: 'Topics',
    icon: FileSignature,
    path: '/exam-manager/topics',
    roles: ['EXAM_MANAGER', 'Exam Manager'],
  },
  {
    id: 'em-audit-logs',
    title: 'Audit Logs',
    icon: Activity,
    path: '/exam-manager/audit-logs',
    roles: ['EXAM_MANAGER', 'Exam Manager'],
  },
  // --- Paper Setter Routes ---
  {
    id: 'ps-dashboard',
    title: 'Dashboard',
    icon: Home,
    path: '/dashboard/paper-setter',
    roles: ['PAPER_SETTER', 'Paper Setter'],
  },
  // --- Govt Authority Routes ---
  {
    id: 'govt-dashboard',
    title: 'Dashboard',
    icon: Home,
    path: '/dashboard/govt-authority',
    roles: ['GOVT_AUTHORITY', 'Govt Authority', 'Government Authority'],
  },
  {
    id: 'govt-import-centers',
    title: 'Import center assign exam',
    icon: Upload,
    path: '/dashboard/govt-authority/import-centers',
    roles: ['GOVT_AUTHORITY', 'Govt Authority', 'Government Authority'],
  },
  {
    id: 'govt-candidates',
    title: 'Import Candidate',
    icon: Upload,
    path: '/dashboard/govt-authority/import-candidates',
    roles: ['GOVT_AUTHORITY', 'Govt Authority', 'Government Authority'],
  },
  {
    id: 'private-dashboard',
    title: 'Dashboard',
    icon: Home,
    path: '/dashboard/private-authority',
    roles: ['PRIVATE_AUTHORITY', 'Private Authority'],
  },
  {
    id: 'private-import-centers',
    title: 'Import Center Assign Exam',
    icon: FileText,
    path: '/dashboard/private-authority/import-centers',
    roles: ['PRIVATE_AUTHORITY', 'Private Authority'],
  },
  {
    id: 'private-candidates',
    title: 'Import Candidate',
    icon: Upload,
    path: '/dashboard/private-authority/import-candidates',
    roles: ['PRIVATE_AUTHORITY', 'Private Authority'],
  },
  // --- Entry Checker Routes ---
  {
    id: 'ec-dashboard',
    title: 'Dashboard',
    icon: Home,
    path: '/dashboard/entry-checker',
    roles: ['ENTRY_CHECKER', 'Entry Checker'],
  }
];
