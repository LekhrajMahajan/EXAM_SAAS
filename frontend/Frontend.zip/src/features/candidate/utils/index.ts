// candidate/utils
