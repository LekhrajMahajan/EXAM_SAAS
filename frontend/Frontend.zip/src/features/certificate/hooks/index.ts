// certificate/hooks
