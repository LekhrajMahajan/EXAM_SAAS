import { useAuthStore } from '@/stores/auth/auth.store';
import { usePermissionStore } from '@/stores/permissions/permission.store';
import { tokenStorage } from '../storage/token.storage';
import { resetAllStores } from '@/stores/utils/storeReset';

export const handleUnauthorized = () => {
  // Clear local token storage
  tokenStorage.clearTokens();
  
  // Reset all Zustand stores (logs user out in UI)
  resetAllStores();
  
  // Redirect to login if not already there
  if (window.location.pathname !== '/auth/login') {
    window.location.href = '/auth/login?reason=unauthorized';
  }
};

export const handleForbidden = () => {
  console.warn('User attempted to access a forbidden resource.');
  // Redirect to a dedicated 403 page or dashboard
};

export const handleSessionExpired = () => {
  tokenStorage.clearTokens();
  resetAllStores();
  window.location.href = '/auth/login?reason=expired';
};
