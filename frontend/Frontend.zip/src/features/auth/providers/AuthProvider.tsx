import React, { useEffect, useRef } from 'react';
import { useAuthStore } from '@/stores/auth/auth.store';
import { useUserStore } from '@/stores/user/user.store';
import { usePermissionStore } from '@/stores/permissions/permission.store';
import { tokenStorage } from '../storage/token.storage';
import { authService } from '../services/auth.service';
import { resetAllStores } from '@/stores/utils/storeReset';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { status, login, logout } = useAuthStore();
  const setProfile = useUserStore(state => state.setProfile);
  const setPermissions = usePermissionStore(state => state.setPermissions);
  const initialized = useRef(false);

  useEffect(() => {
    // Hydrate token on mount
    const hydrateSession = async () => {
      const tokens = tokenStorage.getTokens();
      if (tokens) {
        try {
          // Set to loading so guards like RoleGuard wait
          useAuthStore.setState({ status: 'loading' });
          
          const response = await authService.getProfile();
          
          if (response.success && response.data) {
            const { role, permissions, ...profileData } = response.data;
            
            // Populate user store
            setProfile({
              id: profileData.id,
              name: profileData.name,
              email: profileData.email,
              roleId: role,
              companyId: profileData.companyId,
              subscriptionPlan: profileData.subscriptionPlan,
              paymentStatus: profileData.paymentStatus,
              subscriptionEndDate: profileData.subscriptionEndDate,
              planFeatures: profileData.planFeatures,
              onboardingCompleted: profileData.onboardingCompleted,
            });
            
            // Populate permissions store
            setPermissions({
              roles: role ? [role] : [],
              permissions: permissions || [],
            });
            
            // Set authenticated status
            login({
              accessToken: tokens.accessToken,
              refreshToken: tokens.refreshToken,
            });
          } else {
            resetAllStores();
          }
        } catch (_error) {
          resetAllStores();
        }
      } else {
        resetAllStores();
      }
    };

    if (!initialized.current) {
      initialized.current = true;
      hydrateSession();
    }
  }, [status, login, logout, setProfile, setPermissions]);

  return <>{children}</>;
};
