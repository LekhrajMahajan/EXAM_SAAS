import { CenterHeader } from "../components/CenterHeader";
import { CenterFilters } from "../components/CenterFilters";
import { CenterTable } from "../components/CenterTable";
import { Button } from "@/shared/components/ui/button";
import { Plus, Download, RefreshCw, ShieldCheck } from "lucide-react";
import { Link } from "react-router-dom";
import { MOCK_CENTERS } from "../utils/mockData";

export const CenterListPage = () => {
  return (
    <div className="space-y-6 p-6">
      <CenterHeader
        title="Centers"
        description="Manage all your company centers, infrastructure, and capacity."
        actions={
          <>
            <Link to="/company/centers/pending-verifications">
              <Button variant="outline" size="sm" className="hidden sm:inline-flex bg-amber-500/10 border-amber-500/30 text-amber-600 hover:bg-amber-500/20 font-semibold">
                <ShieldCheck className="h-4 w-4 mr-2" />
                Pending Verifications
              </Button>
            </Link>
            <Button variant="outline" size="sm" className="hidden md:flex">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" size="sm" className="hidden md:flex">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Link to="/company/centers/create">
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Center
              </Button>
            </Link>
          </>
        }
      />

      <CenterFilters />
      
      <CenterTable centers={MOCK_CENTERS} />
      
      <div className="flex items-center justify-between px-2 py-4 border-t">
        <div className="text-sm text-muted-foreground">
          Showing 1 to {MOCK_CENTERS.length} of {MOCK_CENTERS.length} entries
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" disabled>Previous</Button>
          <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">1</Button>
          <Button variant="outline" size="sm" disabled>Next</Button>
        </div>
      </div>
    </div>
  );
};
