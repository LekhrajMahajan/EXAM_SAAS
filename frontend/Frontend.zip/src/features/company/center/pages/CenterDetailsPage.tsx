import { CenterHeader } from "../components/CenterHeader";
import { CenterStatistics } from "../components/CenterStatistics";
import { CenterStatusBadge } from "../components/CenterStatusBadge";
import { Button } from "@/shared/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/shared/components/ui/card";
import { ArrowLeft, Edit, MapPin, Phone, Mail, User, Building } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { MOCK_CENTERS } from "../utils/mockData";

export const CenterDetailsPage = () => {
  const { id } = useParams();
  const center = MOCK_CENTERS.find(c => c.id === id) || MOCK_CENTERS[0];

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-4">
        <Link to="/company/centers">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <CenterHeader
            title={center.centerName}
            description={`Code: ${center.centerCode} | Branch: ${center.branch}`}
            actions={
              <>
                <CenterStatusBadge status={center.status} />
                <CenterStatusBadge status={center.approvalStatus} />
                <Link to={`/company/centers/${center.id}/edit`}>
                  <Button size="sm">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Center
                  </Button>
                </Link>
              </>
            }
          />
        </div>
      </div>

      <CenterStatistics capacity={center.capacity} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Location Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="text-sm text-muted-foreground">Address</div>
              <div className="font-medium">{center.address}</div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-sm text-muted-foreground">City</div>
                <div className="font-medium">{center.city}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">State</div>
                <div className="font-medium">{center.state}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Pincode</div>
                <div className="font-medium">{center.pincode}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Contact Person
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="text-sm text-muted-foreground">Center Head</div>
              <div className="font-medium">{center.headName}</div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span>{center.headEmail}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <span>{center.headMobile}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Link to={`/company/centers/${center.id}/infrastructure`}>
                <Button variant="outline">View Infrastructure</Button>
              </Link>
              <Link to={`/company/centers/${center.id}/rooms`}>
                <Button variant="outline">Manage Rooms</Button>
              </Link>
              <Link to={`/company/centers/${center.id}/devices`}>
                <Button variant="outline">Manage Devices</Button>
              </Link>
              <Link to={`/company/centers/${center.id}/documents`}>
                <Button variant="outline">View Documents</Button>
              </Link>
              <Link to={`/company/centers/${center.id}/approval`}>
                <Button variant="outline">Approval Status</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
