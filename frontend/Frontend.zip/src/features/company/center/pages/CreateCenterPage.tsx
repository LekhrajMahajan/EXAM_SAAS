import { CenterHeader } from "../components/CenterHeader";
import { CenterForm } from "../components/CenterForm";
import { Button } from "@/shared/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export const CreateCenterPage = () => {
  return (
    <div className="space-y-6 p-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-4">
        <Link to="/company/centers">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <CenterHeader
          title="Create New Center"
          description="Enter the details to register a new examination center."
        />
      </div>

      <CenterForm />
    </div>
  );
};
