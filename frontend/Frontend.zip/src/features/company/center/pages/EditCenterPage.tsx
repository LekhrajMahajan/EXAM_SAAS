import { CenterHeader } from "../components/CenterHeader";
import { CenterForm } from "../components/CenterForm";
import { Button } from "@/shared/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { MOCK_CENTERS } from "../utils/mockData";

export const EditCenterPage = () => {
  const { id } = useParams();
  const center = MOCK_CENTERS.find(c => c.id === id) || MOCK_CENTERS[0];

  const initialValues = {
    centerName: center.centerName,
    centerCode: center.centerCode,
    branch: center.branch,
    state: center.state,
    city: center.city,
    address: center.address,
    pincode: center.pincode,
    headName: center.headName,
    headEmail: center.headEmail,
    headMobile: center.headMobile,
    maxCandidates: center.capacity.maxCandidates,
    maxRooms: center.capacity.maxRooms,
    maxSystems: center.capacity.maxSystems,
    status: center.status,
  };

  return (
    <div className="space-y-6 p-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-4">
        <Link to={`/company/centers/${center.id}`}>
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <CenterHeader
          title="Edit Center"
          description={`Updating details for ${center.centerName}`}
        />
      </div>

      <CenterForm initialValues={initialValues} isEditing />
    </div>
  );
};
