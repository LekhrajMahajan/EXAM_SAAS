import { CenterHeader } from "../components/CenterHeader";
import { RoomTable } from "../components/RoomTable";
import { Button } from "@/shared/components/ui/button";
import { ArrowLeft, Plus } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { MOCK_CENTERS, MOCK_ROOMS } from "../utils/mockData";

export const RoomsPage = () => {
  const { id } = useParams();
  const center = MOCK_CENTERS.find(c => c.id === id) || MOCK_CENTERS[0];

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-4">
        <Link to={`/company/centers/${center.id}`}>
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <CenterHeader
            title="Manage Rooms"
            description={`Configuring rooms for ${center.centerName}`}
            actions={
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Room
              </Button>
            }
          />
        </div>
      </div>

      <RoomTable rooms={MOCK_ROOMS} />
    </div>
  );
};
