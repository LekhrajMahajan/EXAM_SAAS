import { CenterHeader } from "../components/CenterHeader";
import { DocumentViewer } from "../components/DocumentViewer";
import { Button } from "@/shared/components/ui/button";
import { ArrowLeft, Upload } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { MOCK_CENTERS, MOCK_DOCUMENTS } from "../utils/mockData";

export const DocumentsPage = () => {
  const { id } = useParams();
  const center = MOCK_CENTERS.find(c => c.id === id) || MOCK_CENTERS[0];

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-4">
        <Link to={`/company/centers/${center.id}`}>
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <CenterHeader
            title="Documents"
            description={`Required compliance documents for ${center.centerName}`}
            actions={
              <Button size="sm">
                <Upload className="h-4 w-4 mr-2" />
                Upload Document
              </Button>
            }
          />
        </div>
      </div>

      <DocumentViewer documents={MOCK_DOCUMENTS} />
    </div>
  );
};
