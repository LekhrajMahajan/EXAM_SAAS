import { CenterHeader } from "../components/CenterHeader";
import { InfrastructureCard } from "../components/InfrastructureCard";
import { Button } from "@/shared/components/ui/button";
import { ArrowLeft, Edit } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { MOCK_CENTERS, MOCK_INFRASTRUCTURE } from "../utils/mockData";

export const InfrastructurePage = () => {
  const { id } = useParams();
  const center = MOCK_CENTERS.find(c => c.id === id) || MOCK_CENTERS[0];

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-4">
        <Link to={`/company/centers/${center.id}`}>
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <CenterHeader
            title="Infrastructure Details"
            description={`Managing infrastructure for ${center.centerName}`}
            actions={
              <Button size="sm">
                <Edit className="h-4 w-4 mr-2" />
                Update Infrastructure
              </Button>
            }
          />
        </div>
      </div>

      <InfrastructureCard data={MOCK_INFRASTRUCTURE} />
    </div>
  );
};
