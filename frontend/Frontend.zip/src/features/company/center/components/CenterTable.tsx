import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/shared/components/ui/table";
import { Button } from "@/shared/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/components/ui/dropdown-menu";
import { MoreHorizontal, Edit, Eye, Building2, MonitorSmartphone, FileText, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { CenterStatusBadge } from "./CenterStatusBadge";
import type { Center } from "../types/center.types";

interface CenterTableProps {
  centers: Center[];
}

export const CenterTable = ({ centers }: CenterTableProps) => {
  return (
    <div className="rounded-md border bg-white">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Center Code</TableHead>
            <TableHead>Center Name</TableHead>
            <TableHead>Branch</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Capacity</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Approval</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {centers.map((center) => (
            <TableRow key={center.id}>
              <TableCell className="font-medium">{center.centerCode}</TableCell>
              <TableCell>{center.centerName}</TableCell>
              <TableCell>{center.branch}</TableCell>
              <TableCell>
                <div className="text-sm">
                  {center.city}
                  <span className="text-muted-foreground block text-xs">
                    {center.state}
                  </span>
                </div>
              </TableCell>
              <TableCell>
                <div className="text-sm">
                  Rooms: {center.capacity.maxRooms}
                  <span className="text-muted-foreground block text-xs">
                    Systems: {center.capacity.maxSystems}
                  </span>
                </div>
              </TableCell>
              <TableCell>
                <CenterStatusBadge status={center.status} />
              </TableCell>
              <TableCell>
                <CenterStatusBadge status={center.approvalStatus} />
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Open menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <Link to={`/company/centers/${center.id}`}>
                      <DropdownMenuItem className="cursor-pointer">
                        <Eye className="mr-2 h-4 w-4" />
                        View Details
                      </DropdownMenuItem>
                    </Link>
                    <Link to={`/company/centers/${center.id}/edit`}>
                      <DropdownMenuItem className="cursor-pointer">
                        <Edit className="mr-2 h-4 w-4" />
                        Edit Info
                      </DropdownMenuItem>
                    </Link>
                    <Link to={`/company/centers/${center.id}/infrastructure`}>
                      <DropdownMenuItem className="cursor-pointer">
                        <Building2 className="mr-2 h-4 w-4" />
                        Infrastructure
                      </DropdownMenuItem>
                    </Link>
                    <Link to={`/company/centers/${center.id}/rooms`}>
                      <DropdownMenuItem className="cursor-pointer">
                        <MonitorSmartphone className="mr-2 h-4 w-4" />
                        Rooms & Devices
                      </DropdownMenuItem>
                    </Link>
                    <Link to={`/company/centers/${center.id}/documents`}>
                      <DropdownMenuItem className="cursor-pointer">
                        <FileText className="mr-2 h-4 w-4" />
                        Documents
                      </DropdownMenuItem>
                    </Link>
                    <Link to={`/company/centers/${center.id}/approval`}>
                      <DropdownMenuItem className="cursor-pointer">
                        <CheckCircle2 className="mr-2 h-4 w-4" />
                        Approval Status
                      </DropdownMenuItem>
                    </Link>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
          {centers.length === 0 && (
            <TableRow>
              <TableCell colSpan={8} className="h-24 text-center">
                No centers found.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};
