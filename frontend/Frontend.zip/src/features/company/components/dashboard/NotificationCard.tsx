import { Card, CardContent, CardHeader, CardTitle } from "@/shared/components/ui/card";
import { Bell } from "lucide-react";
import { Button } from "@/shared/components/ui/button";

interface NotificationItem {
  id: string | number;
  title: string;
  message: string;
  isRead: boolean;
  time: string;
}

interface NotificationCardProps {
  notifications: NotificationItem[];
}

export const NotificationCard = ({ notifications }: NotificationCardProps) => {
  return (
    <Card className="col-span-1 h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Notifications
        </CardTitle>
        <Button variant="ghost" size="sm" className="h-8 text-xs text-primary">
          Mark all as read
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {notifications.length > 0 ? (
            notifications.map((notification) => (
              <div 
                key={notification.id} 
                className={`p-3 rounded-md border ${notification.isRead ? 'bg-background' : 'bg-primary/5 border-primary/20'}`}
              >
                <div className="flex justify-between items-start mb-1">
                  <h4 className="text-sm font-semibold">{notification.title}</h4>
                  <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">
                    {notification.time}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">
                  {notification.message}
                </p>
              </div>
            ))
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              You&apos;re all caught up!
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
