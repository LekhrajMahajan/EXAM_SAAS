import { Card, CardContent, CardHeader, CardTitle } from "@/shared/components/ui/card";
import { Activity } from "lucide-react";

interface ActivityItem {
  id: string | number;
  action: string;
  entity: string;
  time: string;
}

interface RecentActivityCardProps {
  activities: ActivityItem[];
}

export const RecentActivityCard = ({ activities }: RecentActivityCardProps) => {
  return (
    <Card className="col-span-1 h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          {activities.length > 0 ? (
            activities.map((activity) => (
              <div key={activity.id} className="flex items-center">
                <span className="flex h-2 w-2 rounded-full bg-primary" />
                <div className="ml-4 space-y-1">
                  <p className="text-sm font-medium leading-none">{activity.action}</p>
                  <p className="text-sm text-muted-foreground">
                    {activity.entity}
                  </p>
                </div>
                <div className="ml-auto font-medium text-xs text-muted-foreground">
                  {activity.time}
                </div>
              </div>
            ))
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              No recent activity found.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
