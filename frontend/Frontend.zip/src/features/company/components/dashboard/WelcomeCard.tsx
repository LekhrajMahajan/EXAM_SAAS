import { Card, CardContent } from "@/shared/components/ui/card";
import { Button } from "@/shared/components/ui/button";

interface WelcomeCardProps {
  companyName: string;
  adminName: string;
}

export const WelcomeCard = ({ companyName, adminName }: WelcomeCardProps) => {
  return (
    <Card className="bg-primary/5 border-primary/10 mb-8">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-primary mb-1">
              Welcome back, {adminName}!
            </h2>
            <p className="text-muted-foreground">
              Here is what&apos;s happening with <span className="font-medium text-foreground">{companyName}</span> today.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline">View Profile</Button>
            <Button>Create Exam</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
