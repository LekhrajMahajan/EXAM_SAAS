import type { ReactNode } from "react";

interface StatisticsGridProps {
  children: ReactNode;
}

export const StatisticsGrid = ({ children }: StatisticsGridProps) => {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mb-8">
      {children}
    </div>
  );
};
