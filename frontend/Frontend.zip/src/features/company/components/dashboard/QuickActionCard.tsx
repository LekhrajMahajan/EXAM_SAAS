import { Card, CardContent, CardHeader, CardTitle } from "@/shared/components/ui/card";
import { Button } from "@/shared/components/ui/button";
import type { LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

interface QuickAction {
  title: string;
  icon: LucideIcon;
  path: string;
  colorClass?: string;
}

interface QuickActionCardProps {
  actions: QuickAction[];
}

export const QuickActionCard = ({ actions }: QuickActionCardProps) => {
  return (
    <Card className="col-span-1 h-full">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {actions.map((action) => (
            <Link key={action.title} to={action.path}>
              <Button 
                variant="outline" 
                className="w-full h-24 flex flex-col items-center justify-center gap-2 hover:bg-muted"
              >
                <action.icon className={`h-6 w-6 ${action.colorClass || 'text-primary'}`} />
                <span className="text-sm font-medium text-wrap text-center">{action.title}</span>
              </Button>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
