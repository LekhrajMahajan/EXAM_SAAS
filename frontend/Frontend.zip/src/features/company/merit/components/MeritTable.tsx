import React from 'react';
import type { MeritRecord } from '../types';
import { Button } from '@/shared/components/ui/button';
import { Link } from 'react-router-dom';
import { Eye, CheckCircle, Clock, User } from 'lucide-react';
import { cn } from '@/utils/cn';
import { Avatar, AvatarImage, AvatarFallback } from '@/shared/components/ui/avatar';

interface MeritTableProps {
  records: MeritRecord[];
}

export function MeritTable({ records }: MeritTableProps) {

  const getPublishBadge = (status: string) => {
    switch (status) {
      case 'Published': return <span className="flex items-center text-primary text-xs font-medium"><CheckCircle className="w-3 h-3 mr-1" /> Published</span>;
      case 'Scheduled': return <span className="flex items-center text-blue-500 text-xs font-medium"><Clock className="w-3 h-3 mr-1" /> Scheduled</span>;
      default: return <span className="flex items-center text-muted-foreground text-xs font-medium"><Clock className="w-3 h-3 mr-1" /> Draft</span>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Qualified': return <span className="px-2 py-1 rounded bg-emerald-50 text-emerald-700 text-xs font-medium border border-emerald-200">Qualified</span>;
      case 'Not Qualified': return <span className="px-2 py-1 rounded bg-red-50 text-red-700 text-xs font-medium border border-red-200">Not Qualified</span>;
      case 'Generated': return <span className="px-2 py-1 rounded bg-blue-500/10 text-blue-500 text-xs font-medium border border-blue-500/20">Generated</span>;
      case 'Published': return <span className="px-2 py-1 rounded bg-primary/10 text-primary text-xs font-medium border border-primary/20">Published</span>;
      default: return <span className="px-2 py-1 rounded bg-muted text-muted-foreground text-xs font-medium border border-border">{status}</span>;
    }
  };

  const getPhotoUrl = (photoUrl?: string) => {
    if (!photoUrl) return undefined;
    if (photoUrl.startsWith('http') || photoUrl.startsWith('data:')) return photoUrl;
    const baseUrl = import.meta.env.VITE_API_BASE_URL?.replace('/api/v1', '') || 'http://localhost:5000';
    return `${baseUrl}/${photoUrl.replace(/^\//, '')}`;
  };

  if (records.length === 0) {
    return (
      <div className="text-center p-12 bg-muted/50 border border-border border-dashed rounded-xl">
        <p className="text-muted-foreground">No merit records found.</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border overflow-hidden shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-muted-foreground">
          <thead className="text-xs text-foreground uppercase bg-muted/50 border-b border-border">
            <tr>
              <th scope="col" className="px-6 py-4">Rank</th>
              <th scope="col" className="px-6 py-4 text-center">Photo</th>
              <th scope="col" className="px-6 py-4">Candidate Name</th>
              <th scope="col" className="px-6 py-4">Application No.</th>
              <th scope="col" className="px-6 py-4">Category</th>
              <th scope="col" className="px-6 py-4">Marks</th>
              <th scope="col" className="px-6 py-4">Percentage</th>
              <th scope="col" className="px-6 py-4">Status</th>
              <th scope="col" className="px-6 py-4">Record Status</th>
              <th scope="col" className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {records.map((record) => {
              const cand = (record as any).candidateId || {};
              const dynamic = cand.dynamicFields || {};
              const candidatePhoto = cand.photo || cand.profilePicture || cand.candidatePhoto || dynamic.photo || dynamic.candidatePhoto || dynamic.profilePicture;
              const candidateName = record.candidateName || cand.fullName || cand.candidateFullName || cand.firstName || cand.name || dynamic.fullName || dynamic.candidateFullName || dynamic.name || 'Unknown Candidate';
              const applicationNo = record.applicationNumber || cand.applicationNo || cand.applicationNumber || cand.enrollmentNo || dynamic.applicationNo || dynamic.applicationNumber || dynamic.enrollmentNo || '-';
              
              return (
              <tr key={record.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                   <div className="flex items-baseline gap-1">
                      <span className="text-muted-foreground font-bold text-xs">#</span>
                      <span className="text-lg font-extrabold text-foreground">{record.ranks.overallRank}</span>
                   </div>
                   {record.ranks.categoryRank && (
                      <div className="text-[10px] font-medium text-primary bg-primary/10 px-1.5 py-0.5 rounded inline-block mt-1">
                        {record.category}: #{record.ranks.categoryRank}
                      </div>
                   )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap flex justify-center">
                  <Avatar className="w-10 h-10 border border-border">
                    <AvatarImage src={getPhotoUrl(candidatePhoto)} alt={candidateName} />
                    <AvatarFallback className="text-muted-foreground"><User className="w-5 h-5" /></AvatarFallback>
                  </Avatar>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="font-semibold text-foreground">{candidateName}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="font-medium text-muted-foreground">{applicationNo}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-xs">
                  <span className="px-2 py-1 rounded bg-muted border border-border text-foreground font-medium">
                     {record.category}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="font-bold text-foreground">{record.marksObtained}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className={cn("text-sm font-medium", record.percentage >= 40 ? "text-emerald-600" : "text-destructive")}>{record.percentage}%</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {getStatusBadge(record.status)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {getPublishBadge(record.publishStatus)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  <Button variant="outline" size="sm" asChild className="bg-card">
                    <Link to={`/company/merit/${record.id}`}>
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Link>
                  </Button>
                </td>
              </tr>
            )})}
          </tbody>
        </table>

      </div>
    </div>
  );
}
