import React from 'react';
import { RankCard } from './RankCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/shared/components/ui/card';
import { User, MapPin } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/shared/components/ui/avatar';

interface CandidateRankCardProps {
  record: any; // Accept any to handle both IMeritList and MeritRecord gracefully
}

export function CandidateRankCard({ record }: CandidateRankCardProps) {
  // Map properties safely from IMeritList if it is an IMeritList
  const cand = (record as any).candidateId || {};
  const photo = cand.photo || cand.profilePicture || cand.candidatePhoto;
  const candidateName = cand.fullName || cand.candidateFullName || cand.firstName || cand.name || 'Unknown Candidate';
  const applicationNumber = cand.applicationNo || cand.applicationNumber || cand.enrollmentNo || 'N/A';
  const category = record.category || 'General';
  const state = record.state || 'N/A';
  const city = record.city || 'N/A';
  
  const marksObtained = record.marksObtained ?? 0;
  const percentage = record.percentage ?? 0;
  
  const overallRank = record.overallRank ?? record.ranks?.overallRank ?? '-';
  const categoryRank = record.rank ?? record.ranks?.categoryRank ?? '-';
  const stateRank = record.ranks?.stateRank ?? '-';
  const cityRank = record.ranks?.cityRank ?? '-';

  const getPhotoUrl = (photoUrl?: string) => {
    if (!photoUrl) return undefined;
    if (photoUrl.startsWith('http') || photoUrl.startsWith('data:')) return photoUrl;
    const baseUrl = import.meta.env.VITE_API_BASE_URL?.replace('/api/v1', '') || 'http://localhost:5000';
    return `${baseUrl}/${photoUrl.replace(/^\//, '')}`;
  };

  return (
    <Card className="border-border shadow-sm overflow-hidden">
      <div className="bg-muted/50 border-b border-border p-6 flex flex-col sm:flex-row items-center gap-6">
         <div className="w-20 h-20 bg-card border-2 border-border rounded-full flex items-center justify-center shadow-sm flex-shrink-0 overflow-hidden">
            <Avatar className="w-full h-full">
               <AvatarImage src={getPhotoUrl(photo)} alt={candidateName} />
               <AvatarFallback className="text-muted-foreground"><User className="w-10 h-10" /></AvatarFallback>
            </Avatar>
         </div>
         <div className="text-center sm:text-left flex-1">
           <h3 className="font-bold text-foreground text-xl">{candidateName}</h3>
           <p className="text-sm text-muted-foreground font-mono mt-1">App No: {applicationNumber}</p>
           <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-3">
             <span className="px-2 py-1 rounded bg-card border border-border text-xs font-semibold text-foreground">{category}</span>
             <span className="px-2 py-1 rounded bg-card border border-border text-xs font-medium text-muted-foreground flex items-center gap-1">
               <MapPin className="w-3 h-3" /> {city}, {state}
             </span>
           </div>
         </div>
         <div className="text-center sm:text-right bg-card p-4 rounded-xl border border-border shadow-sm min-w-[120px]">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Total Score</p>
            <p className="text-2xl font-black text-foreground">{marksObtained}</p>
            <p className="text-xs font-medium text-emerald-600 mt-1">{percentage}%</p>
         </div>
      </div>
      <CardContent className="p-6 bg-muted/20">
         <h4 className="font-semibold text-foreground mb-4">Rankings Breakdown</h4>
         <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <RankCard label="Overall Rank" rank={overallRank} type="overall" />
            <RankCard label="Category Rank" rank={categoryRank} type="category" />
            <RankCard label="State Rank" rank={stateRank} type="state" />
            <RankCard label="City Rank" rank={cityRank} type="city" />
         </div>
      </CardContent>
    </Card>
  );
}
