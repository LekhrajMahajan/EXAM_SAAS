import React from 'react';
import { PageHeader } from '@/shared/components/layout/page-header';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { generateMeritSchema, type GenerateMeritForm } from '../schemas/merit-schemas';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/shared/components/ui/card';
import { Button } from '@/shared/components/ui/button';
import { FileDown, Loader2 } from 'lucide-react';
import { PreviewCard, type PreviewData } from '../components/PreviewCard';
import { useState, useEffect } from 'react';
import api from '@/services/api';
import { apiClient } from '@/core/api/http/axios-client';
import { toast } from 'react-hot-toast';

const MERIT_TYPES = ['Overall', 'Category-wise', 'State-wise', 'City-wise'];
const TIE_BREAKERS = [
  'Date of Birth (Older candidate preferred)',
  'Higher marks in Section A',
  'Alphabetical order of names',
  'Earlier application submission time'
];

export function GenerateMeritPage() {
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [exams, setExams] = useState<any[]>([]);

  useEffect(() => {
    const fetchExams = async () => {
      try {
        const response = await apiClient.get('/exams?limit=100');
        if (response.data?.data) {
          setExams(response.data.data);
        }
      } catch (error) {
        console.error('Failed to fetch exams:', error);
      }
    };
    fetchExams();
  }, []);

  const { register, handleSubmit, formState: { errors } } = useForm<GenerateMeritForm>({
    resolver: zodResolver(generateMeritSchema),
    defaultValues: {
      meritType: 'Overall',
      tieBreakingRules: [],
    }
  });

  const onSubmit = async (data: GenerateMeritForm) => {
    setIsSimulating(true);
    try {
      // Connect to the real backend API dynamically
      const response = await apiClient.post('/merit-lists/generate-from-results', {
        examId: data.exam,
      });
      
      const resData = response.data?.data;
      if (resData) {
        toast.success(`Successfully generated merit list.`);
        // Assuming response has ranked array or we construct a generic preview
        setPreviewData({
          candidatesProcessed: resData.totalResults || 0,
          topScore: resData.ranked?.[0]?.marksObtained || 0,
          maxScore: resData.ranked?.[0]?.totalMarks || 100,
          tieBreakersApplied: 0,
          topCandidates: resData.ranked?.slice(0, 3).map((r: any, idx: number) => ({
            id: r._id,
            name: r.candidateId?.fullName || r.candidateId?.firstName || `Candidate ${idx + 1}`,
            category: r.category || 'General',
            state: r.state || 'N/A',
            score: r.marksObtained
          })) || []
        });
      }
    } catch (error: any) {
      console.error(error);
      toast.error(error.response?.data?.message || 'Failed to generate merit list.');
    } finally {
      setIsSimulating(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <PageHeader 
        title="Generate Merit List" 
        description="Compute candidate rankings and resolve ties based on configured rules." 
      />

      <Card className="border-slate-200 shadow-sm">
        <CardHeader className="bg-slate-50/50 border-b border-slate-100">
          <CardTitle className="text-lg">Generation Parameters</CardTitle>
          <CardDescription>Select the dataset and define how ranks should be calculated.</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Exam Batch <span className="text-red-500">*</span></label>
                <select 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
                  {...register('exam')}
                >
                  <option value="">Select Exam Batch</option>
                  {exams.map(exam => (
                    <option key={exam._id} value={exam._id}>
                      {exam.examTitle}
                    </option>
                  ))}
                </select>
                {errors.exam && <p className="text-xs text-red-500">{errors.exam.message}</p>}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Merit Type <span className="text-red-500">*</span></label>
                <select 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
                  {...register('meritType')}
                >
                  {MERIT_TYPES.map(type => <option key={type} value={type}>{type}</option>)}
                </select>
                {errors.meritType && <p className="text-xs text-red-500">{errors.meritType.message}</p>}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Category Filter (Optional)</label>
                <select 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
                  {...register('category')}
                >
                  <option value="">All Categories</option>
                  <option value="General">General</option>
                  <option value="OBC">OBC</option>
                  <option value="SC">SC</option>
                  <option value="ST">ST</option>
                  <option value="EWS">EWS</option>
                </select>
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-bold text-slate-700 border-b border-slate-100 pb-2 block">Tie-Breaking Rules Priority <span className="text-red-500">*</span></label>
              <p className="text-xs text-slate-500">Select the rules to apply when candidates have the exact same score.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
                 {TIE_BREAKERS.map((rule, idx) => (
                    <label key={rule} className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card cursor-pointer hover:bg-muted/50 transition-colors">
                      <input 
                         type="checkbox" 
                         value={rule}
                         {...register('tieBreakingRules')}
                         className="w-4 h-4 text-primary rounded border-input"
                      />
                      <span className="text-sm font-medium text-foreground flex-1">{rule}</span>
                      <span className="text-xs text-muted-foreground font-mono bg-muted/20 px-2 rounded border border-border shadow-sm">Priority {idx + 1}</span>
                    </label>
                 ))}
              </div>
              {errors.tieBreakingRules && <p className="text-xs text-red-500">{errors.tieBreakingRules.message}</p>}
            </div>

            <div className="pt-6 border-t border-border flex justify-end">
              <Button type="submit" disabled={isSimulating}>
                {isSimulating ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Simulating...</> : 'Generate Merit Simulation'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <div className="mt-12">
        <div>
          <PreviewCard data={previewData} isLoading={isSimulating} />
        </div>
        <div className="mt-6 flex justify-end">
           <Button>
             <FileDown className="w-4 h-4 mr-2" />
             Save & Commit Merit List
           </Button>
        </div>
      </div>
    </div>
  );
}
