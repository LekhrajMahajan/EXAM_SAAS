import React, { useState, useEffect } from 'react';
import { PageHeader } from '@/shared/components/layout/page-header';
import { useParams, Link } from 'react-router-dom';
import { useMeritLists } from '../hooks/merit.hooks';
import { CandidateRankCard } from '../components/CandidateRankCard';
import { Button } from '@/shared/components/ui/button';
import { ChevronLeft, Loader2, CheckCircle, XCircle } from 'lucide-react';
import { apiClient } from '@/core/api/http/axios-client';
import { ResultAnswersView } from '../../result/components/ResultAnswersView';
import { Card, CardContent } from '@/shared/components/ui/card';

export function MeritDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const { data, isLoading } = useMeritLists();
  
  const records = data?.data || [];
  const record = records.find((r: any) => r._id === id || r.id === id) || records[0];

  const [resultDetails, setResultDetails] = useState<any>(null);
  const [loadingResult, setLoadingResult] = useState(false);

  useEffect(() => {
    const fetchResultDetails = async () => {
      // Find the associated result ID
      const resultId = record?.resultId?._id || record?.resultId || record?.result;
      if (!resultId) return;

      try {
        setLoadingResult(true);
        const res = await apiClient.get(`/results/${resultId}/details`);
        if (res.data?.data) {
          setResultDetails(res.data.data);
        }
      } catch (err) {
        console.error("Failed to fetch detailed results", err);
      } finally {
        setLoadingResult(false);
      }
    };

    if (record && !isLoading) {
      fetchResultDetails();
    }
  }, [record, isLoading]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild className="text-muted-foreground hover:text-foreground">
            <Link to="/company/merit/list">
              <ChevronLeft className="w-5 h-5" />
            </Link>
          </Button>
          <PageHeader title="Merit & Rank Details" description="Loading..." />
        </div>
      </div>
    );
  }

  if (!record) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild className="text-muted-foreground hover:text-foreground">
            <Link to="/company/merit/list">
              <ChevronLeft className="w-5 h-5" />
            </Link>
          </Button>
          <PageHeader title="Merit & Rank Details" description="Record not found." />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild className="text-muted-foreground hover:text-foreground">
          <Link to="/company/merit/list">
            <ChevronLeft className="w-5 h-5" />
          </Link>
        </Button>
        <PageHeader 
          title="Merit & Rank Details" 
          description={`Viewing comprehensive rank profile for ${record.candidateName || record.candidateId?.fullName || 'Candidate'} (${record.applicationNumber || record.candidateId?.applicationNo || 'N/A'})`} 
        />
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
         <CandidateRankCard record={record} />
         
         {/* Qualification Status Card */}
         {(record as any).resultId?.passStatus && (
           <Card className="border-border shadow-sm">
             <CardContent className="p-6">
               <div className="flex items-center gap-4">
                 <div className={`p-3 rounded-full ${(record as any).resultId.passStatus === 'FAILED' ? 'bg-red-100 text-red-600' : 'bg-emerald-100 text-emerald-600'}`}>
                   {(record as any).resultId.passStatus === 'FAILED' ? (
                     <XCircle className="w-8 h-8" />
                   ) : (
                     <CheckCircle className="w-8 h-8" />
                   )}
                 </div>
                 <div>
                   <p className="text-sm font-medium text-muted-foreground">Qualification Status</p>
                   <h3 className={`text-2xl font-bold ${(record as any).resultId.passStatus === 'FAILED' ? 'text-red-600' : 'text-emerald-600'}`}>
                     {(record as any).resultId.passStatus === 'FAILED' ? 'Not Qualified' : 'Qualified'}
                   </h3>
                 </div>
               </div>
             </CardContent>
           </Card>
         )}

         {/* Subject-Wise Breakdown */}
         {loadingResult ? (
            <div className="flex justify-center p-8">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
         ) : resultDetails?.answers && (
            <div className="mt-8">
               <div className="flex items-center gap-2 mb-4">
                 <h3 className="text-lg font-semibold text-foreground">Subject-Wise Breakdown</h3>
               </div>
               
               <Card className="border-border shadow-sm overflow-hidden">
                 <div className="overflow-x-auto">
                   <table className="w-full text-sm text-left">
                     <thead className="text-xs text-foreground uppercase bg-muted/50 border-b border-border">
                       <tr>
                         <th className="px-6 py-4">Subject</th>
                         <th className="px-6 py-4 text-center">Attempted</th>
                         <th className="px-6 py-4 text-center">Correct</th>
                         <th className="px-6 py-4 text-center">Wrong</th>
                         <th className="px-6 py-4 text-center">Marks</th>
                         <th className="px-6 py-4 text-center">Cutoff</th>
                         <th className="px-6 py-4 text-center">Status</th>
                       </tr>
                     </thead>
                     <tbody>
                       {(() => {
                         let breakdownData: any[] = [];
                         
                         const result = record?.resultId;
                         if (result?.subjectWiseBreakdown && Array.isArray(result.subjectWiseBreakdown) && result.subjectWiseBreakdown.length > 0) {
                           breakdownData = result.subjectWiseBreakdown;
                         } else if (resultDetails?.answers && resultDetails.answers.length > 0) {
                           const grouped = resultDetails.answers.reduce((acc: any, curr: any) => {
                             const subjectName = curr.subject || (record as any).subject || resultDetails.exam?.name || 'General';
                             if (!acc[subjectName]) {
                               acc[subjectName] = { name: subjectName, attempted: 0, correct: 0, wrong: 0, marks: 0, maxMarks: 0, cutoff: 0 };
                             }
                             if (curr.isAnswered) acc[subjectName].attempted += 1;
                             if (curr.isCorrect) acc[subjectName].correct += 1;
                             if (curr.isAnswered && !curr.isCorrect) acc[subjectName].wrong += 1;
                             
                             const pMarks = Number(curr.marks) || 1;
                             const nMarks = Number(curr.negativeMarks) || 0;
                             acc[subjectName].maxMarks += pMarks;
                             
                             if (curr.isCorrect) acc[subjectName].marks += pMarks;
                             else if (curr.isAnswered) acc[subjectName].marks -= nMarks;
                             
                             return acc;
                           }, {});
                           
                           breakdownData = Object.values(grouped);
                         }
                         
                         if (breakdownData.length === 0 && result) {
                           // Fallback for imported candidates without detailed subject breakdown
                           const cand = (record as any)?.candidateId || {};
                           const dynamicFields = cand?.dynamicFields || {};
                           const subjectName = cand?.paperSubject || (record as any)?.subject || resultDetails?.exam?.name || 'General';
                           
                           // Dynamically fetch cutoff from dynamic fields or use a default 40% calculation
                           const dynamicCutoff = cand?.cutoff || dynamicFields?.cutoff || dynamicFields?.Cutoff || dynamicFields?.['Cut Off'] || dynamicFields?.['Cutoff Marks'] || (result.totalMarks ? result.totalMarks * 0.4 : 0);
                           
                           breakdownData = [{
                             name: subjectName,
                             attempted: result.attemptedQuestions || 0,
                             correct: result.correctAnswers || 0,
                             wrong: result.wrongAnswers || 0,
                             marks: result.marksObtained || 0,
                             maxMarks: result.totalMarks || 0,
                             cutoff: dynamicCutoff,
                             sectionalStatus: result.passStatus || 'NOT_QUALIFIED'
                           }];
                         }
                         
                         if (breakdownData.length === 0) {
                           return (
                             <tr>
                               <td colSpan={7} className="px-6 py-8 text-center text-muted-foreground">
                                 No subject-wise breakdown available.
                               </td>
                             </tr>
                           );
                         }

                         return breakdownData.map((data, idx) => {
                           const name = data.subjectName || data.name;
                           const attempted = data.questionsAttempted ?? data.attempted;
                           const correct = data.correctAnswers ?? data.correct;
                           const wrong = data.wrongAnswers ?? data.wrong;
                           const marks = data.marksObtained ?? data.marks;
                           
                           // Set a mock cutoff as 40% of maxMarks for demonstration if none exists
                           const cutoff = data.sectionalCutoff ?? data.cutoff ?? (data.maxMarks ? data.maxMarks * 0.4 : 0);
                           const isQualified = data.sectionalStatus === 'QUALIFIED' || (data.sectionalStatus !== 'NOT_QUALIFIED' && marks >= cutoff);
                           
                           return (
                             <tr key={idx} className="border-b border-border last:border-0 hover:bg-muted/30">
                               <td className="px-6 py-4 font-semibold text-foreground">{name}</td>
                               <td className="px-6 py-4 text-center font-medium">{attempted}</td>
                               <td className="px-6 py-4 text-center">
                                 <div className="flex items-center justify-center gap-1.5 text-emerald-600 font-bold">
                                   <CheckCircle className="w-4 h-4" /> {correct}
                                 </div>
                               </td>
                               <td className="px-6 py-4 text-center">
                                 <div className="flex items-center justify-center gap-1.5 text-red-600 font-bold">
                                   <XCircle className="w-4 h-4" /> {wrong}
                                 </div>
                               </td>
                               <td className="px-6 py-4 text-center font-bold text-foreground">
                                 {marks}
                               </td>
                               <td className="px-6 py-4 text-center text-muted-foreground">
                                 {typeof cutoff === 'number' ? cutoff.toFixed(1) : cutoff}
                               </td>
                               <td className="px-6 py-4 text-center">
                                 <span className={`px-2 py-1 rounded text-xs font-semibold ${isQualified ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                                   {isQualified ? 'Qualified' : 'Not Qualified'}
                                 </span>
                               </td>
                             </tr>
                           );
                         });
                       })()}
                     </tbody>
                   </table>
                 </div>
               </Card>
            </div>
         )}

         {/* Detailed Question Analysis */}
         {resultDetails?.answers && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold text-foreground mb-4">Question Analysis (Answers vs Correct)</h3>
              <ResultAnswersView answers={resultDetails.answers || []} />
            </div>
         )}
      </div>
    </div>
  );
}
