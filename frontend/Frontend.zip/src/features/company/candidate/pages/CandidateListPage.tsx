import { CandidateHeader } from "../components/CandidateHeader";
import { CandidateFilters } from "../components/CandidateFilters";
import { CandidateTable } from "../components/CandidateTable";
import { Button } from "@/shared/components/ui/button";
import { Plus, Download, RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";
import { MOCK_CANDIDATES } from "../utils/mockData";

export const CandidateListPage = () => {
  return (
    <div className="space-y-6 p-6">
      <CandidateHeader
        title="Candidate Management"
        description="View, filter, and manage registered candidates and their applications."
        actions={
          <>
            <Button variant="outline" size="sm" className="hidden md:flex">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Link to="/company/candidates/export">
              <Button variant="outline" size="sm" className="hidden md:flex">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </Link>
            <Link to="/company/candidates/create">
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Candidate
              </Button>
            </Link>
          </>
        }
      />

      <CandidateFilters />
      
      <CandidateTable candidates={MOCK_CANDIDATES} />
      
      <div className="flex items-center justify-between px-2 py-4 border-t bg-white rounded-b-md">
        <div className="text-sm text-muted-foreground">
          Showing 1 to {MOCK_CANDIDATES.length} of {MOCK_CANDIDATES.length} entries
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" disabled>Previous</Button>
          <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">1</Button>
          <Button variant="outline" size="sm" disabled>Next</Button>
        </div>
      </div>
    </div>
  );
};
