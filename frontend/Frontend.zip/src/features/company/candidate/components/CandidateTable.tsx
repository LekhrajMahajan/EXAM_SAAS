import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/shared/components/ui/table";
import { Button } from "@/shared/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/components/ui/dropdown-menu";
import { MoreHorizontal, Edit, Eye, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { CandidateStatusBadge } from "./CandidateStatusBadge";
import { Avatar, AvatarFallback, AvatarImage } from "@/shared/components/ui/avatar";
import type { Candidate } from "../types/candidate.types";

interface CandidateTableProps {
  candidates: Candidate[];
}

export const CandidateTable = ({ candidates }: CandidateTableProps) => {
  return (
    <div className="rounded-md border bg-white overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Candidate</TableHead>
              <TableHead>Application No</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Exam & Shift</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {candidates.map((candidate) => (
              <TableRow key={candidate.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={`https://ui-avatars.com/api/?name=${candidate.firstName}+${candidate.lastName}&background=random`} />
                      <AvatarFallback>{candidate.firstName[0]}{candidate.lastName[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium text-primary">
                        {candidate.firstName} {candidate.middleName ? candidate.middleName + ' ' : ''}{candidate.lastName}
                      </div>
                      <div className="text-xs text-muted-foreground">{candidate.gender}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="font-medium">{candidate.applicationNo}</div>
                  <div className="text-xs text-muted-foreground">Aadhaar: {candidate.aadhaarNumber}</div>
                </TableCell>
                <TableCell>
                  <div className="text-sm">{candidate.mobile}</div>
                  <div className="text-xs text-muted-foreground">{candidate.email}</div>
                </TableCell>
                <TableCell>
                  <div className="text-sm font-medium">{candidate.exam}</div>
                  <div className="text-xs text-muted-foreground">{candidate.shift}</div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col gap-1 items-start">
                    <CandidateStatusBadge status={candidate.status} />
                    {candidate.approvalStatus !== 'Pending' && (
                       <CandidateStatusBadge status={candidate.approvalStatus} />
                    )}
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <Link to={`/company/candidates/${candidate.id}`}>
                        <DropdownMenuItem className="cursor-pointer">
                          <Eye className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                      </Link>
                      <Link to={`/company/candidates/${candidate.id}/edit`}>
                        <DropdownMenuItem className="cursor-pointer">
                          <Edit className="mr-2 h-4 w-4" />
                          Edit Profile
                        </DropdownMenuItem>
                      </Link>
                      <DropdownMenuItem className="cursor-pointer text-green-600">
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Approve
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
            {candidates.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  No candidates found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
