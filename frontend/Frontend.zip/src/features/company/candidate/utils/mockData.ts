import type { Candidate } from "../types/candidate.types";

export const MOCK_CANDIDATES: Candidate[] = [
  {
    id: "c1",
    applicationNo: "APP-2026-0001",
    firstName: "Rohan",
    middleName: "Kumar",
    lastName: "Das",
    gender: "Male",
    dateOfBirth: "1998-08-12",
    category: "General",
    nationality: "Indian",
    aadhaarNumber: "123456789012",
    mobile: "+91 9876543210",
    email: "rohan.das@example.com",
    emergencyContact: "+91 9988776655",
    currentAddress: "12, Park Street, Kolkata",
    permanentAddress: "12, Park Street, Kolkata",
    state: "West Bengal",
    city: "Kolkata",
    education: [
      { qualification: "B.Tech", boardUniversity: "WBUT", passingYear: "2020", percentage: "85%" }
    ],
    exam: "TCS NQT 2026",
    shift: "Morning (09:00 AM)",
    status: "Approved",
    approvalStatus: "Approved",
    createdAt: "2026-06-15T10:00:00Z"
  },
  {
    id: "c2",
    applicationNo: "APP-2026-0002",
    firstName: "Sneha",
    lastName: "Reddy",
    gender: "Female",
    dateOfBirth: "2000-03-25",
    category: "OBC",
    nationality: "Indian",
    aadhaarNumber: "987654321098",
    mobile: "+91 8765432109",
    email: "sneha.reddy@example.com",
    emergencyContact: "+91 8877665544",
    currentAddress: "45, Jubilee Hills, Hyderabad",
    permanentAddress: "45, Jubilee Hills, Hyderabad",
    state: "Telangana",
    city: "Hyderabad",
    education: [
      { qualification: "B.E.", boardUniversity: "Osmania University", passingYear: "2022", percentage: "90%" }
    ],
    exam: "TCS NQT 2026",
    shift: "Afternoon (02:00 PM)",
    status: "Submitted",
    approvalStatus: "Pending",
    createdAt: "2026-06-20T11:30:00Z"
  },
  {
    id: "c3",
    applicationNo: "APP-2026-0003",
    firstName: "Amit",
    lastName: "Singh",
    gender: "Male",
    dateOfBirth: "1999-11-05",
    category: "SC",
    nationality: "Indian",
    aadhaarNumber: "112233445566",
    mobile: "+91 7654321098",
    email: "amit.singh@example.com",
    emergencyContact: "+91 7766554433",
    currentAddress: "Sector 14, Gurugram",
    permanentAddress: "Sector 14, Gurugram",
    state: "Haryana",
    city: "Gurugram",
    education: [
      { qualification: "MCA", boardUniversity: "MDU", passingYear: "2023", percentage: "78%" }
    ],
    exam: "Infosys Certification",
    shift: "Morning (09:00 AM)",
    status: "Draft",
    approvalStatus: "Pending",
    createdAt: "2026-07-01T09:15:00Z"
  }
];
