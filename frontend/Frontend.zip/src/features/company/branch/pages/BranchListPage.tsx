import { Button } from "@/shared/components/ui/button";
import { Plus, Download, RefreshCw, Loader2, ShieldCheck } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { BranchHeader } from "../components/BranchHeader";
import { BranchFilters } from "../components/BranchFilters";
import { BranchTable } from "../components/BranchTable";
import { useBranches } from "../hooks/branch.hooks";
import { GenericPagination } from "@/shared/components/pagination/GenericPagination";

export const BranchListPage = () => {
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  
  const { data: response, isLoading, refetch } = useBranches({ page, limit });
  const branches = response?.data || [];
  const meta = response?.meta;

  return (
    <div className="space-y-6">
      <BranchHeader
        title="Branches"
        description="Manage all your company branches and centers."
        actions={
          <>
            <Link to="/company/branches/pending-verifications">
              <Button variant="outline" size="sm" className="hidden sm:inline-flex bg-amber-500/10 border-amber-500/30 text-amber-600 hover:bg-amber-500/20 font-semibold">
                <ShieldCheck className="h-4 w-4 mr-2" />
                Pending Verifications
              </Button>
            </Link>
            <Button variant="outline" size="sm" className="hidden md:flex" onClick={() => refetch()}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" size="sm" className="hidden md:flex">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Link to="/company/branches/create">
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Branch
              </Button>
            </Link>
          </>
        }
      />

      <BranchFilters />
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64 border rounded-md">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <BranchTable branches={branches} />
      )}
      
      {meta && (
        <GenericPagination
          pageIndex={page - 1}
          pageSize={limit}
          totalCount={meta.total}
          onPageChange={(newPageIndex) => setPage(newPageIndex + 1)}
          onPageSizeChange={setLimit}
        />
      )}
    </div>
  );
};
