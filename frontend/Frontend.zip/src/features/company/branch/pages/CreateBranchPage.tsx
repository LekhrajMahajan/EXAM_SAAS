import { BranchHeader } from "../components/BranchHeader";
import { BranchForm } from "../components/BranchForm";

export const CreateBranchPage = () => {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <BranchHeader
        title="Create Branch"
        description="Add a new branch to your company infrastructure."
      />
      <div className="pb-12">
        <BranchForm />
      </div>
    </div>
  );
};
