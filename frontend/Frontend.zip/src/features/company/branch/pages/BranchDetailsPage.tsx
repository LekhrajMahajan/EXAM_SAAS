import { BranchHeader } from "../components/BranchHeader";
import { BranchDetailsCard } from "../components/BranchDetailsCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/shared/components/ui/tabs";
import { Button } from "@/shared/components/ui/button";
import { Edit } from "lucide-react";
import { Link } from "react-router-dom";
import { BranchStatusBadge } from "../components/BranchStatusBadge";

const MOCK_BRANCH_DATA = {
  general: {
    branchName: "Mumbai Central",
    branchCode: "BR-001",
    company: "Tech Innovators Inc.",
    state: "Maharashtra",
    city: "Mumbai",
    address: "123 Business Park, Andheri East",
    pincode: "400069",
  },
  contact: {
    contactPerson: "Rahul Sharma",
    mobile: "+91 9876543210",
    email: "rahul.s@techinnovators.com",
  },
  head: {
    headName: "Vikram Singh",
    headMobile: "+91 9988776655",
    headEmail: "vikram.s@techinnovators.com",
  }
};

export const BranchDetailsPage = () => {
  return (
    <div className="space-y-6">
      <BranchHeader
        title="Branch Details"
        description={`Detailed view for ${MOCK_BRANCH_DATA.general.branchCode}`}
        actions={
          <div className="flex items-center gap-4">
            <BranchStatusBadge isActive={true} />
            <Link to="/company/branches/1/edit">
              <Button size="sm">
                <Edit className="h-4 w-4 mr-2" />
                Edit Branch
              </Button>
            </Link>
          </div>
        }
      />

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="general">General Information</TabsTrigger>
          <TabsTrigger value="contact">Contact Details</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="activity">Activity Log</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general" className="space-y-6">
          <BranchDetailsCard title="Basic Information" data={MOCK_BRANCH_DATA.general} />
          <BranchDetailsCard title="Branch Head Information" data={MOCK_BRANCH_DATA.head} />
        </TabsContent>
        
        <TabsContent value="contact">
          <BranchDetailsCard title="Primary Contact" data={MOCK_BRANCH_DATA.contact} />
        </TabsContent>
        
        <TabsContent value="documents">
          <div className="rounded-md border p-8 text-center text-muted-foreground bg-muted/10">
            [ Documents Module Placeholder ]
          </div>
        </TabsContent>
        
        <TabsContent value="activity">
          <div className="rounded-md border p-8 text-center text-muted-foreground bg-muted/10">
            [ Activity Log Module Placeholder ]
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
