import { BranchHeader } from "../components/BranchHeader";
import { BranchForm } from "../components/BranchForm";
import { useParams } from "react-router-dom";
import { useBranch } from "../hooks/branch.hooks";
import { Loader2 } from "lucide-react";

export const EditBranchPage = () => {
  const { id } = useParams<{ id: string }>();
  const { data: response, isLoading } = useBranch(id || "");
  const branch = response?.data;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <BranchHeader
        title="Edit Branch"
        description="Update information for the selected branch."
      />
      <div className="pb-12">
        {isLoading ? (
          <div className="flex justify-center items-center h-64 border rounded-md">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : branch ? (
          <>
            {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
            <BranchForm initialData={branch as any} isEdit />
          </>
        ) : (
          <div className="text-center p-6 border rounded-md">Branch not found</div>
        )}
      </div>
    </div>
  );
};
