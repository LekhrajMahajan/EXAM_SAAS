import mongoose from "mongoose";
import { env } from "./env";
import dns from "dns";

// Force Node.js to use Google DNS to bypass any local Windows DNS cache or ISP issues
dns.setServers(['8.8.8.8', '8.8.4.4']);

export const connectDatabase = async () => {
    try {
        mongoose.set("strictQuery", true);

        const connection = await mongoose.connect(env.MONGODB_URI, {
            family: 4
        });

        console.log(
            `MongoDB Connected : ${connection.connection.host}`
        );
    } catch (error) {
        console.error(error);

        process.exit(1);
    }
};

mongoose.connection.on("connected", () => {
    console.log("Database Connected");
});

mongoose.connection.on("disconnected", () => {
    console.log("Database Disconnected");
});

mongoose.connection.on("error", (err) => {
    console.log(err);
});