import Candidate from "../candidate/candidate.model";
import Exam from "../exam/exam.model";
import Result from "../result/result.model";
import { AttendanceModel as Attendance } from "../attendance/attendance.model";
import Question from "../question-bank/question.model";
import Company from "../company/company.model";
import Branch from "../branch/branch.model";
import Center from "../center/center.model";
import Employee from "../employee/employee.model";
import Notification from "../notification/notification.model";

class AnalyticsRepository {
  /*
    |--------------------------------------------------------------------------
    | Candidate Analytics
    |--------------------------------------------------------------------------
    */

  async getCandidateAnalytics(filter: Record<string, unknown> = {}) {
    return Candidate.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Exam Analytics
    |--------------------------------------------------------------------------
    */

  async getExamAnalytics(filter: Record<string, unknown> = {}) {
    return Exam.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Result Analytics
    |--------------------------------------------------------------------------
    */

  async getResultAnalytics(filter: Record<string, unknown> = {}) {
    return Result.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Attendance Analytics
    |--------------------------------------------------------------------------
    */

  async getAttendanceAnalytics(filter: Record<string, unknown> = {}) {
    return Attendance.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Question Analytics
    |--------------------------------------------------------------------------
    */

  async getQuestionAnalytics(filter: Record<string, unknown> = {}) {
    return Question.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Company Analytics
    |--------------------------------------------------------------------------
    */

  async getCompanyAnalytics(filter: Record<string, unknown> = {}) {
    return Company.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Branch Analytics
    |--------------------------------------------------------------------------
    */

  async getBranchAnalytics(filter: Record<string, unknown> = {}) {
    return Branch.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Center Analytics
    |--------------------------------------------------------------------------
    */

  async getCenterAnalytics(filter: Record<string, unknown> = {}) {
    return Center.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Employee Analytics
    |--------------------------------------------------------------------------
    */

  async getEmployeeAnalytics(filter: Record<string, unknown> = {}) {
    return Employee.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Notification Analytics
    |--------------------------------------------------------------------------
    */

  async getNotificationAnalytics(filter: Record<string, unknown> = {}) {
    return Notification.aggregate([
      {
        $match: filter,
      },
    ]);
  }

  /*
    |--------------------------------------------------------------------------
    | Queue Analytics
    |--------------------------------------------------------------------------
    */

  async getQueueAnalytics() {
    /*
        |--------------------------------------------------------------------------
        | TODO
        |--------------------------------------------------------------------------
        |
        | BullMQ Queue Statistics
        |
        */

    return {
      waiting: 0,

      active: 0,

      completed: 0,

      failed: 0,

      delayed: 0,
    };
  }

  /*
    |--------------------------------------------------------------------------
    | System Analytics
    |--------------------------------------------------------------------------
    */

  async getSystemAnalytics() {
    /*
        |--------------------------------------------------------------------------
        | TODO
        |--------------------------------------------------------------------------
        |
        | Redis Statistics
        | API Statistics
        | WebSocket Statistics
        | Server Statistics
        |
        */

    return {
      apiRequests: 0,

      websocketConnections: 0,

      redisHits: 0,

      memoryUsage: process.memoryUsage(),

      uptime: process.uptime(),
    };
  }
}

export default new AnalyticsRepository();
