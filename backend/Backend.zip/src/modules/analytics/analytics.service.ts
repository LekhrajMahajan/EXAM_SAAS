import analyticsRepository from "./analytics.repository";
import { IAnalyticsFilter, AnalyticsPeriod } from "./analytics.types";

class AnalyticsService {
  /*
    |--------------------------------------------------------------------------
    | Overview
    |--------------------------------------------------------------------------
    */

  async getOverview(filter: IAnalyticsFilter) {
    return {
      period: filter.period ?? AnalyticsPeriod.TODAY,

      candidates: await analyticsRepository.getCandidateAnalytics(),

      exams: await analyticsRepository.getExamAnalytics(),

      results: await analyticsRepository.getResultAnalytics(),

      attendance: await analyticsRepository.getAttendanceAnalytics(),
    };
  }

  /*
    |--------------------------------------------------------------------------
    | Candidate Analytics
    |--------------------------------------------------------------------------
    */

  async getCandidateAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getCandidateAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Exam Analytics
    |--------------------------------------------------------------------------
    */

  async getExamAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getExamAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Result Analytics
    |--------------------------------------------------------------------------
    */

  async getResultAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getResultAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Attendance Analytics
    |--------------------------------------------------------------------------
    */

  async getAttendanceAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getAttendanceAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Question Analytics
    |--------------------------------------------------------------------------
    */

  async getQuestionAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getQuestionAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Company Analytics
    |--------------------------------------------------------------------------
    */

  async getCompanyAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getCompanyAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Branch Analytics
    |--------------------------------------------------------------------------
    */

  async getBranchAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getBranchAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Center Analytics
    |--------------------------------------------------------------------------
    */

  async getCenterAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getCenterAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Employee Analytics
    |--------------------------------------------------------------------------
    */

  async getEmployeeAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getEmployeeAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Notification Analytics
    |--------------------------------------------------------------------------
    */

  async getNotificationAnalytics(filter: IAnalyticsFilter) {
    return analyticsRepository.getNotificationAnalytics(filter);
  }

  /*
    |--------------------------------------------------------------------------
    | Queue Analytics
    |--------------------------------------------------------------------------
    */

  async getQueueAnalytics() {
    return analyticsRepository.getQueueAnalytics();
  }

  /*
    |--------------------------------------------------------------------------
    | System Analytics
    |--------------------------------------------------------------------------
    */

  async getSystemAnalytics() {
    return analyticsRepository.getSystemAnalytics();
  }

  /*
    |--------------------------------------------------------------------------
    | Dashboard Analytics
    |--------------------------------------------------------------------------
    */

  async getDashboardAnalytics(filter: IAnalyticsFilter) {
    const [candidates, exams, results, attendance, companies] = await Promise.all([
      this.getCandidateAnalytics(filter),

      this.getExamAnalytics(filter),

      this.getResultAnalytics(filter),

      this.getAttendanceAnalytics(filter),

      this.getCompanyAnalytics(filter),
    ]);

    return {
      candidates,

      exams,

      results,

      attendance,

      companies,
    };
  }

  /*
    |--------------------------------------------------------------------------
    | Chart Analytics
    |--------------------------------------------------------------------------
    */

  async getChartAnalytics(filter: IAnalyticsFilter) {
    /*
        |--------------------------------------------------------------------------
        | TODO
        |--------------------------------------------------------------------------
        |
        | Registration Trend
        | Result Trend
        | Attendance Trend
        | Exam Trend
        |
        */

    return {
      labels: [],

      datasets: [],
    };
  }
}

export default new AnalyticsService();
