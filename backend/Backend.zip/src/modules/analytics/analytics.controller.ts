import { Request, Response } from "express";
import httpStatus from "http-status";

import { asyncHandler } from "../../utils/asyncHandler";
import { sendResponse } from "../../utils/response";

import analyticsService from "./analytics.service";

import { IAnalyticsFilter } from "./analytics.types";

/*
|--------------------------------------------------------------------------
| Overview
|--------------------------------------------------------------------------
*/

export const getOverview = asyncHandler(async (req: Request, res: Response) => {
  const analytics = await analyticsService.getOverview(
    req.query as IAnalyticsFilter,
  );

  sendResponse(res, httpStatus.OK, {
    success: true,

    message: "Overview analytics fetched successfully.",

    data: analytics,
  });
});

/*
|--------------------------------------------------------------------------
| Candidate Analytics
|--------------------------------------------------------------------------
*/

export const getCandidateAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getCandidateAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Candidate analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Exam Analytics
|--------------------------------------------------------------------------
*/

export const getExamAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getExamAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Exam analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Result Analytics
|--------------------------------------------------------------------------
*/

export const getResultAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getResultAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Result analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Attendance Analytics
|--------------------------------------------------------------------------
*/

export const getAttendanceAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getAttendanceAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Attendance analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Question Analytics
|--------------------------------------------------------------------------
*/

export const getQuestionAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getQuestionAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Question analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Company Analytics
|--------------------------------------------------------------------------
*/

export const getCompanyAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getCompanyAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Company analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Branch Analytics
|--------------------------------------------------------------------------
*/

export const getBranchAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getBranchAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Branch analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Center Analytics
|--------------------------------------------------------------------------
*/

export const getCenterAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getCenterAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Center analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Employee Analytics
|--------------------------------------------------------------------------
*/

export const getEmployeeAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getEmployeeAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Employee analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Notification Analytics
|--------------------------------------------------------------------------
*/

export const getNotificationAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getNotificationAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Notification analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Queue Analytics
|--------------------------------------------------------------------------
*/

export const getQueueAnalytics = asyncHandler(
  async (_req: Request, res: Response) => {
    const analytics = await analyticsService.getQueueAnalytics();

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Queue analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| System Analytics
|--------------------------------------------------------------------------
*/

export const getSystemAnalytics = asyncHandler(
  async (_req: Request, res: Response) => {
    const analytics = await analyticsService.getSystemAnalytics();

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "System analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Dashboard Analytics
|--------------------------------------------------------------------------
*/

export const getDashboardAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getDashboardAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Dashboard analytics fetched successfully.",

      data: analytics,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Chart Analytics
|--------------------------------------------------------------------------
*/

export const getChartAnalytics = asyncHandler(
  async (req: Request, res: Response) => {
    const analytics = await analyticsService.getChartAnalytics(
      req.query as IAnalyticsFilter,
    );

    sendResponse(res, httpStatus.OK, {
      success: true,

      message: "Chart analytics fetched successfully.",

      data: analytics,
    });
  },
);
