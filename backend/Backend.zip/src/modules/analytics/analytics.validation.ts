import { z } from "zod";

import {
  AnalyticsPeriod,
  AnalyticsCategory,
  ChartType,
} from "./analytics.types";

/*
|--------------------------------------------------------------------------
| Common ObjectId
|--------------------------------------------------------------------------
*/

const objectId = z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid ObjectId.");

/*
|--------------------------------------------------------------------------
| Analytics Filter
|--------------------------------------------------------------------------
*/

export const analyticsFilterSchema = z.object({
  query: z.object({
    period: z.nativeEnum(AnalyticsPeriod).optional(),

    startDate: z.coerce.date().optional(),

    endDate: z.coerce.date().optional(),

    companyId: objectId.optional(),

    branchId: objectId.optional(),

    centerId: objectId.optional(),

    examId: objectId.optional(),

    subjectId: objectId.optional(),
  }),
});

/*
|--------------------------------------------------------------------------
| Overview Analytics
|--------------------------------------------------------------------------
*/

export const overviewAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Candidate Analytics
|--------------------------------------------------------------------------
*/

export const candidateAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Exam Analytics
|--------------------------------------------------------------------------
*/

export const examAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Result Analytics
|--------------------------------------------------------------------------
*/

export const resultAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Attendance Analytics
|--------------------------------------------------------------------------
*/

export const attendanceAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Question Analytics
|--------------------------------------------------------------------------
*/

export const questionAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Company Analytics
|--------------------------------------------------------------------------
*/

export const companyAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Branch Analytics
|--------------------------------------------------------------------------
*/

export const branchAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Center Analytics
|--------------------------------------------------------------------------
*/

export const centerAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Employee Analytics
|--------------------------------------------------------------------------
*/

export const employeeAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| System Analytics
|--------------------------------------------------------------------------
*/

export const systemAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Notification Analytics
|--------------------------------------------------------------------------
*/

export const notificationAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Queue Analytics
|--------------------------------------------------------------------------
*/

export const queueAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Dashboard Analytics
|--------------------------------------------------------------------------
*/

export const dashboardAnalyticsSchema = analyticsFilterSchema;

/*
|--------------------------------------------------------------------------
| Chart Analytics
|--------------------------------------------------------------------------
*/

export const chartAnalyticsSchema = z.object({
  query: z.object({
    category: z.nativeEnum(AnalyticsCategory),

    chartType: z.nativeEnum(ChartType),

    period: z.nativeEnum(AnalyticsPeriod).optional(),

    startDate: z.coerce.date().optional(),

    endDate: z.coerce.date().optional(),
  }),
});
