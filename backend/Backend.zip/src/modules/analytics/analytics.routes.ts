import { Router } from "express";

import { authenticate } from "../../middleware/authenticate";
import { authorize } from "../../middleware/authorize";
import { validate as validateRequest } from "../../middleware/validate";

import { UserRole } from "../../constants/roles";

import {
  getOverview,
  getCandidateAnalytics,
  getExamAnalytics,
  getResultAnalytics,
  getAttendanceAnalytics,
  getQuestionAnalytics,
  getCompanyAnalytics,
  getBranchAnalytics,
  getCenterAnalytics,
  getEmployeeAnalytics,
  getNotificationAnalytics,
  getQueueAnalytics,
  getSystemAnalytics,
  getDashboardAnalytics,
  getChartAnalytics,
} from "./analytics.controller";

import {
  overviewAnalyticsSchema,
  candidateAnalyticsSchema,
  examAnalyticsSchema,
  resultAnalyticsSchema,
  attendanceAnalyticsSchema,
  questionAnalyticsSchema,
  companyAnalyticsSchema,
  branchAnalyticsSchema,
  centerAnalyticsSchema,
  employeeAnalyticsSchema,
  notificationAnalyticsSchema,
  queueAnalyticsSchema,
  systemAnalyticsSchema,
  dashboardAnalyticsSchema,
  chartAnalyticsSchema,
} from "./analytics.validation";

const router = Router();

/*
|--------------------------------------------------------------------------
| Overview
|--------------------------------------------------------------------------
*/

router.get(
  "/overview",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,

    UserRole.EXAM_MANAGER,
  ),

  validateRequest(overviewAnalyticsSchema),

  getOverview,
);

/*
|--------------------------------------------------------------------------
| Candidate
|--------------------------------------------------------------------------
*/

router.get(
  "/candidates",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,

    UserRole.EXAM_MANAGER,
  ),

  validateRequest(candidateAnalyticsSchema),

  getCandidateAnalytics,
);

/*
|--------------------------------------------------------------------------
| Exam
|--------------------------------------------------------------------------
*/

router.get(
  "/exams",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,

    UserRole.EXAM_MANAGER,
  ),

  validateRequest(examAnalyticsSchema),

  getExamAnalytics,
);

/*
|--------------------------------------------------------------------------
| Result
|--------------------------------------------------------------------------
*/

router.get(
  "/results",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,

    UserRole.EXAM_MANAGER,
  ),

  validateRequest(resultAnalyticsSchema),

  getResultAnalytics,
);

/*
|--------------------------------------------------------------------------
| Attendance
|--------------------------------------------------------------------------
*/

router.get(
  "/attendance",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,

    UserRole.EXAM_MANAGER,
  ),

  validateRequest(attendanceAnalyticsSchema),

  getAttendanceAnalytics,
);

/*
|--------------------------------------------------------------------------
| Question
|--------------------------------------------------------------------------
*/

router.get(
  "/questions",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,
  ),

  validateRequest(questionAnalyticsSchema),

  getQuestionAnalytics,
);

/*
|--------------------------------------------------------------------------
| Company
|--------------------------------------------------------------------------
*/

router.get(
  "/companies",

  authenticate,

  authorize(UserRole.MASTER_ADMIN),

  validateRequest(companyAnalyticsSchema),

  getCompanyAnalytics,
);

/*
|--------------------------------------------------------------------------
| Branch
|--------------------------------------------------------------------------
*/

router.get(
  "/branches",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,
  ),

  validateRequest(branchAnalyticsSchema),

  getBranchAnalytics,
);

/*
|--------------------------------------------------------------------------
| Center
|--------------------------------------------------------------------------
*/

router.get(
  "/centers",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,
  ),

  validateRequest(centerAnalyticsSchema),

  getCenterAnalytics,
);

/*
|--------------------------------------------------------------------------
| Employee
|--------------------------------------------------------------------------
*/

router.get(
  "/employees",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,
  ),

  validateRequest(employeeAnalyticsSchema),

  getEmployeeAnalytics,
);

/*
|--------------------------------------------------------------------------
| Notification
|--------------------------------------------------------------------------
*/

router.get(
  "/notifications",

  authenticate,

  authorize(UserRole.MASTER_ADMIN),

  validateRequest(notificationAnalyticsSchema),

  getNotificationAnalytics,
);

/*
|--------------------------------------------------------------------------
| Queue
|--------------------------------------------------------------------------
*/

router.get(
  "/queue",

  authenticate,

  authorize(UserRole.MASTER_ADMIN),

  validateRequest(queueAnalyticsSchema),

  getQueueAnalytics,
);

/*
|--------------------------------------------------------------------------
| System
|--------------------------------------------------------------------------
*/

router.get(
  "/system",

  authenticate,

  authorize(UserRole.MASTER_ADMIN),

  validateRequest(systemAnalyticsSchema),

  getSystemAnalytics,
);

/*
|--------------------------------------------------------------------------
| Dashboard
|--------------------------------------------------------------------------
*/

router.get(
  "/dashboard",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,

    UserRole.EXAM_MANAGER,
  ),

  validateRequest(dashboardAnalyticsSchema),

  getDashboardAnalytics,
);

/*
|--------------------------------------------------------------------------
| Charts
|--------------------------------------------------------------------------
*/

router.get(
  "/charts",

  authenticate,

  authorize(
    UserRole.MASTER_ADMIN,

    UserRole.COMPANY_ADMIN,

    UserRole.EXAM_MANAGER,
  ),

  validateRequest(chartAnalyticsSchema),

  getChartAnalytics,
);

export default router;
