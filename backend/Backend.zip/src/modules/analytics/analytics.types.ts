/*
|--------------------------------------------------------------------------
| Analytics Period
|--------------------------------------------------------------------------
*/

export enum AnalyticsPeriod {
  TODAY = "TODAY",

  WEEK = "WEEK",

  MONTH = "MONTH",

  QUARTER = "QUARTER",

  YEAR = "YEAR",

  CUSTOM = "CUSTOM",
}

/*
|--------------------------------------------------------------------------
| Analytics Category
|--------------------------------------------------------------------------
*/

export enum AnalyticsCategory {
  CANDIDATE = "CANDIDATE",

  EXAM = "EXAM",

  RESULT = "RESULT",

  ATTENDANCE = "ATTENDANCE",

  COMPANY = "COMPANY",

  BRANCH = "BRANCH",

  CENTER = "CENTER",

  QUESTION = "QUESTION",

  PAPER = "PAPER",

  EMPLOYEE = "EMPLOYEE",

  SYSTEM = "SYSTEM",

  QUEUE = "QUEUE",

  NOTIFICATION = "NOTIFICATION",
}

/*
|--------------------------------------------------------------------------
| Chart Type
|--------------------------------------------------------------------------
*/

export enum ChartType {
  LINE = "LINE",

  BAR = "BAR",

  PIE = "PIE",

  DOUGHNUT = "DOUGHNUT",

  AREA = "AREA",

  RADAR = "RADAR",
}

/*
|--------------------------------------------------------------------------
| Analytics Filter
|--------------------------------------------------------------------------
*/

export interface IAnalyticsFilter {
  period?: AnalyticsPeriod;

  startDate?: Date;

  endDate?: Date;

  companyId?: string;

  branchId?: string;

  centerId?: string;

  examId?: string;

  subjectId?: string;

  [key: string]: any;
}

/*
|--------------------------------------------------------------------------
| Chart Dataset
|--------------------------------------------------------------------------
*/

export interface IChartDataset {
  label: string;

  data: number[];

  backgroundColor?: string[];

  borderColor?: string[];
}

/*
|--------------------------------------------------------------------------
| Analytics Chart
|--------------------------------------------------------------------------
*/

export interface IAnalyticsChart {
  type: ChartType;

  labels: string[];

  datasets: IChartDataset[];
}
