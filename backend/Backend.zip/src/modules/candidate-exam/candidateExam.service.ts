import ApiError from "../../utils/ApiError";
import HTTP_STATUS from "http-status";
import { generateAccessToken } from "../../utils/jwt"; // checking if this exists
// I'll just build a basic service

/*
|--------------------------------------------------------------------------
| Candidate Exam Service
|--------------------------------------------------------------------------
*/

class CandidateExamService {
  async login(payload: any) {
    // 1. Verify candidate details, assignment, exam code, etc.
    // Since this is a new module being bootstrapped to resolve the 404, we'll
    // add basic mock resolution for the endpoint.
    
    // In a full implementation, you would:
    // - Check if exam is ACTIVE
    // - Check CandidateAssignment
    // - Validate Password (if added to schema)
    // - Record device & IP info into LiveMonitoring or ActivityLog

    // Generating a realistic mock sessionId
    const crypto = require("crypto");
    const sessionId = crypto.randomBytes(12).toString("hex");

    return {
      candidate: {
        _id: payload.candidateId,
        candidateName: "Rahul Sharma", // Mock name
        enrollmentNo: payload.enrollmentNo,
      },
      exam: {
        _id: "6888abcd1234567890abcdef",
        examTitle: "Java Full Stack Recruitment Exam",
        examCode: payload.examCode,
        examDate: "2026-08-15",
        startTime: "09:30",
        duration: 90
      },
      sessionToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjYW5kaWRhdGVJZCI6IjZhNTRhNWE1NTQxNjVjY2U4ZjEyMDk2ZSIsInNlc3Npb25JZCI6IjY4OTlhYmNkMTIzNDU2Nzg5MGFiY2RlZiIsImlhdCI6MTY5MjEwMDAwMH0.12345abcde",
      sessionId: sessionId,
      nextStep: "FACE_VERIFICATION"
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Face Verification
  |--------------------------------------------------------------------------
  */

  async faceVerification(payload: any) {
    // In a full implementation, you would:
    // - Verify livenessScore against threshold
    // - Check if face matches reference image
    // - Record verification status

    return {
      sessionId: payload.sessionId,
      candidateId: payload.candidateId,
      faceMatched: true,
      confidenceScore: 99.18,
      livenessPassed: true,
      verificationStatus: "VERIFIED",
      verifiedAt: new Date().toISOString(),
      nextStep: "DEVICE_REGISTRATION"
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Device Registration
  |--------------------------------------------------------------------------
  */

  async deviceRegistration(payload: any) {
    // In a full implementation, you would:
    // - Verify fingerprint
    // - Update session with device info
    // - Check if device meets requirements (e.g. webcam, mic)

    return {
      sessionId: payload.sessionId,
      candidateId: payload.candidateId,
      deviceRegistered: true,
      deviceTrusted: true,
      fingerprintMatched: true,
      registeredAt: new Date().toISOString(),
      nextStep: "GEO_VERIFICATION"
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Geo Verification
  |--------------------------------------------------------------------------
  */

  async geoVerification(payload: any) {
    // In a full implementation, you would:
    // - Verify location against allowed boundaries
    // - Check VPN or Mock location usage
    // - Calculate distance from center

    return {
      sessionId: payload.sessionId,
      candidateId: payload.candidateId,
      geoVerified: true,
      distanceFromCenter: 6.8,
      allowedRadius: 50,
      verificationStatus: "VERIFIED",
      verifiedAt: new Date().toISOString(),
      nextStep: "START_EXAM"
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Start Exam
  |--------------------------------------------------------------------------
  */

  async startExam(payload: any) {
    // In a full implementation, you would:
    // - Verify that the exam shift is currently active
    // - Generate an ExamSubmission or CandidateAnswer session
    // - Initialize the timer

    return {
      sessionId: payload.sessionId,
      examId: payload.examId,
      candidateId: payload.candidateId,
      examStatus: "RUNNING",
      remainingTime: 5400,
      firstQuestionId: "6890abcd1234567890abcdef",
      currentQuestionNumber: 1,
      heartbeatEnabled: true,
      autoSaveEnabled: true,
      liveMonitoring: true,
      webcamMonitoring: true,
      tabMonitoring: true,
      screenMonitoring: true,
      fullscreenEnabled: true,
      startedAt: payload.startTime || new Date().toISOString()
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Get Questions
  |--------------------------------------------------------------------------
  */

  async getQuestions(query: any) {
    const questionNo = query.questionNo ? parseInt(query.questionNo) : 1;
    
    // Returning a mock question response
    return {
      sessionId: "6899abcd1234567890abcdef",
      examId: "6888abcd1234567890abcdef",
      candidateId: "6887abcd1234567890abc001",
      remainingTime: 5234,
      currentQuestion: {
        _id: "6890abcd1234567890abcdef",
        questionNumber: questionNo,
        section: "Java",
        questionType: "MCQ",
        difficulty: "MEDIUM",
        marks: 2,
        negativeMarks: 0.5,
        questionText: "Which keyword is used to inherit a class in Java?",
        options: [
          { id: "A", text: "implements" },
          { id: "B", text: "inherits" },
          { id: "C", text: "extends" },
          { id: "D", text: "super" }
        ],
        selectedOption: null,
        answerStatus: "NOT_VISITED",
        markForReview: false
      },
      navigation: {
        current: questionNo,
        totalQuestions: 40,
        previousAvailable: questionNo > 1,
        nextAvailable: questionNo < 40
      },
      questionPalette: {
        answered: 0,
        notAnswered: 0,
        notVisited: 39,
        markedForReview: 0,
        answeredAndMarked: 0
      }
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Save Answer
  |--------------------------------------------------------------------------
  */

  async saveAnswer(payload: any) {
    // In a full implementation, you would:
    // - Save or update CandidateAnswer in database
    // - Calculate question palette metrics
    // - Track audit trails (autoSaved vs manual)

    return {
      sessionId: payload.sessionId,
      questionId: payload.questionId,
      questionNumber: payload.questionNumber,
      selectedOption: payload.selectedOption,
      answerStatus: payload.answerStatus,
      savedAt: payload.savedAt || new Date().toISOString(),
      autoSaved: payload.autoSaved || false,
      questionPalette: {
        answered: payload.answerStatus === "ANSWERED" ? 1 : 0,
        notAnswered: 0,
        notVisited: 39,
        markedForReview: 0,
        answeredAndMarked: 0
      }
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Mark For Review
  |--------------------------------------------------------------------------
  */

  async markForReview(payload: any) {
    let answerStatus = payload.selectedOption ? "ANSWERED_AND_MARKED_FOR_REVIEW" : "MARKED_FOR_REVIEW";
    
    return {
      sessionId: payload.sessionId,
      questionId: payload.questionId,
      questionNumber: payload.questionNumber,
      markForReview: payload.markForReview,
      selectedOption: payload.selectedOption || null,
      answerStatus: answerStatus,
      reviewedAt: payload.reviewedAt || new Date().toISOString(),
      questionPalette: {
        answered: 0,
        notAnswered: 0,
        notVisited: 39,
        markedForReview: payload.selectedOption ? 0 : 1,
        answeredAndMarked: payload.selectedOption ? 1 : 0
      }
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Clear Response
  |--------------------------------------------------------------------------
  */

  async clearResponse(payload: any) {
    return {
      sessionId: payload.sessionId,
      questionId: payload.questionId,
      questionNumber: payload.questionNumber,
      selectedOption: null,
      answerStatus: "NOT_ANSWERED",
      markForReview: payload.clearReviewFlag === true ? false : (payload.markForReview || false),
      clearedAt: payload.clearedAt || new Date().toISOString(),
      questionPalette: {
        answered: 0,
        notAnswered: 1,
        notVisited: 39,
        markedForReview: 0,
        answeredAndMarked: 0
      }
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Save & Next
  |--------------------------------------------------------------------------
  */

  async saveNext(payload: any) {
    const nextQuestionNumber = payload.currentQuestionNumber + 1;
    
    return {
      savedQuestion: {
        questionId: payload.currentQuestionId,
        questionNumber: payload.currentQuestionNumber,
        selectedOption: payload.selectedOption || null,
        answerStatus: payload.selectedOption ? "ANSWERED" : "NOT_ANSWERED"
      },
      nextQuestion: {
        _id: "6890abcd1234567890abcdf0",
        questionNumber: nextQuestionNumber,
        section: "Java",
        questionType: "MCQ",
        marks: 2,
        negativeMarks: 0.5,
        questionText: "Which collection allows duplicate elements?",
        options: [
          { id: "A", text: "HashSet" },
          { id: "B", text: "TreeSet" },
          { id: "C", text: "LinkedHashSet" },
          { id: "D", text: "ArrayList" }
        ],
        selectedOption: null,
        answerStatus: "NOT_VISITED"
      },
      remainingTime: 5180,
      questionPalette: {
        answered: payload.selectedOption ? 1 : 0,
        notAnswered: payload.selectedOption ? 0 : 1,
        notVisited: 38, // Simulating progress
        markedForReview: 0,
        answeredAndMarked: 0
      }
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Previous Question
  |--------------------------------------------------------------------------
  */

  async previousQuestion(query: any) {
    const currentQuestionNumber = query.currentQuestionNumber ? parseInt(query.currentQuestionNumber) : 2;
    const prevQuestionNumber = currentQuestionNumber - 1 > 0 ? currentQuestionNumber - 1 : 1;
    
    return {
      sessionId: query.sessionId || "6899abcd1234567890abcdef",
      currentQuestionNumber: prevQuestionNumber,
      remainingTime: 5148,
      question: {
        _id: "6890abcd1234567890abcdef",
        questionNumber: prevQuestionNumber,
        section: "Java",
        questionType: "MCQ",
        marks: 2,
        negativeMarks: 0.5,
        questionText: "Which keyword is used to inherit a class in Java?",
        options: [
          { id: "A", text: "implements" },
          { id: "B", text: "inherits" },
          { id: "C", text: "extends" },
          { id: "D", text: "super" }
        ],
        selectedOption: "C",
        answerStatus: "ANSWERED",
        markForReview: false
      },
      navigation: {
        previousAvailable: prevQuestionNumber > 1,
        nextAvailable: true
      },
      questionPalette: {
        answered: 1,
        notAnswered: 0,
        notVisited: 38,
        markedForReview: 0,
        answeredAndMarked: 0
      }
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Submit Exam
  |--------------------------------------------------------------------------
  */

  async submitExam(payload: any) {
    return {
      sessionId: payload.sessionId,
      examId: payload.examId,
      candidateId: payload.candidateId,
      examStatus: "SUBMITTED",
      submittedAt: payload.submittedAt || new Date().toISOString(),
      submitType: payload.submitType || "MANUAL",
      summary: {
        totalQuestions: 40,
        answered: 38,
        notAnswered: 2,
        markedForReview: 1,
        answeredAndMarked: 3
      },
      monitoringStopped: true,
      heartbeatStopped: true,
      sessionLocked: true,
      resultStatus: "PROCESSING"
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Auto Submit Exam
  |--------------------------------------------------------------------------
  */

  async autoSubmitExam(payload: any) {
    return {
      sessionId: payload.sessionId,
      examId: payload.examId,
      candidateId: payload.candidateId,
      examStatus: "AUTO_SUBMITTED",
      submitReason: payload.submitReason || "TIME_EXPIRED",
      triggeredBy: payload.triggeredBy || "SYSTEM",
      submittedAt: payload.submittedAt || new Date().toISOString(),
      summary: {
        totalQuestions: 40,
        answered: 37,
        notAnswered: 3,
        markedForReview: 2,
        answeredAndMarked: 4
      },
      sessionLocked: true,
      monitoringStopped: true,
      heartbeatStopped: true,
      resultStatus: "PROCESSING"
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Result Preview
  |--------------------------------------------------------------------------
  */

  async resultPreview(query: any) {
    return {
      sessionId: query.sessionId || "6899abcd1234567890abcdef",
      candidate: {
        _id: query.candidateId || "6887abcd1234567890abc001",
        candidateName: "Rahul Sharma",
        enrollmentNo: "EX20260001"
      },
      exam: {
        _id: query.examId || "6888abcd1234567890abcdef",
        examTitle: "Java Full Stack Recruitment Exam",
        examCode: "EXAM-JAVA-001"
      },
      score: {
        totalMarks: 80,
        obtainedMarks: 68,
        correctAnswers: 34,
        wrongAnswers: 4,
        unanswered: 2,
        percentage: 85
      },
      result: {
        status: "PASS",
        rank: 12,
        grade: "A"
      },
      published: false,
      generatedAt: new Date().toISOString()
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Violation Logs
  |--------------------------------------------------------------------------
  */

  async violationLogs(query: any) {
    return {
      sessionId: query.sessionId || "6899abcd1234567890abcdef",
      candidateId: query.candidateId || "6887abcd1234567890abc001",
      examId: query.examId || "6888abcd1234567890abcdef",
      totalViolations: 4,
      autoSubmitted: false,
      violations: [
        {
          _id: "6899log001",
          violationType: "TAB_SWITCH",
          severity: "MEDIUM",
          count: 2,
          description: "Candidate switched browser tab.",
          actionTaken: "Warning",
          capturedAt: "2026-08-15T09:42:18.000Z"
        },
        {
          _id: "6899log002",
          violationType: "FACE_NOT_VISIBLE",
          severity: "HIGH",
          count: 1,
          description: "Face not detected for 15 seconds.",
          actionTaken: "Alert Sent",
          capturedAt: "2026-08-15T10:05:42.000Z"
        },
        {
          _id: "6899log003",
          violationType: "FULLSCREEN_EXIT",
          severity: "MEDIUM",
          count: 1,
          description: "Candidate exited fullscreen.",
          actionTaken: "Fullscreen Restored",
          capturedAt: "2026-08-15T10:18:55.000Z"
        }
      ]
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Session Heartbeat
  |--------------------------------------------------------------------------
  */

  async sessionHeartbeat(payload: any) {
    return {
      sessionId: payload.sessionId,
      status: "ACTIVE",
      lastHeartbeat: payload.heartbeatAt || new Date().toISOString(),
      remainingTime: payload.remainingTime || 4500,
      serverTime: new Date().toISOString(),
      nextHeartbeatIn: 20,
      warnings: []
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Reconnect Session
  |--------------------------------------------------------------------------
  */

  async reconnectSession(payload: any) {
    return {
      sessionId: payload.sessionId,
      examStatus: "RUNNING",
      currentQuestionNumber: 18,
      remainingTime: 2715,
      lastSavedQuestion: 18,
      heartbeatResumed: true,
      monitoringResumed: true,
      fullscreenRequired: true,
      reconnectedAt: payload.reconnectedAt || new Date().toISOString(),
      warnings: []
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Exam Summary
  |--------------------------------------------------------------------------
  */

  async examSummary(query: any) {
    return {
      sessionId: query.sessionId || "6899abcd1234567890abcdef",
      candidate: {
        _id: query.candidateId || "6887abcd1234567890abc001",
        candidateName: "Rahul Sharma",
        enrollmentNo: "EX20260001"
      },
      exam: {
        _id: query.examId || "6888abcd1234567890abcdef",
        examTitle: "Java Full Stack Recruitment Exam",
        examCode: "EXAM-JAVA-001"
      },
      timeSummary: {
        duration: 90,
        timeUsed: 86,
        timeRemaining: 4
      },
      questionSummary: {
        totalQuestions: 40,
        answered: 38,
        notAnswered: 2,
        markedForReview: 1,
        answeredAndMarked: 3
      },
      sectionSummary: [
        {
          section: "Java",
          answered: 18,
          total: 20
        },
        {
          section: "Spring Boot",
          answered: 20,
          total: 20
        }
      ],
      securitySummary: {
        totalViolations: 4,
        tabSwitches: 2,
        fullscreenExit: 1,
        faceWarnings: 1
      },
      submission: {
        submitType: "MANUAL",
        submittedAt: "2026-08-15T10:58:46.000Z",
        status: "SUBMITTED"
      }
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Final Result
  |--------------------------------------------------------------------------
  */

  async finalResult(query: any) {
    return {
      candidate: {
        _id: query.candidateId || "6887abcd1234567890abc001",
        candidateName: "Rahul Sharma",
        enrollmentNo: "EX20260001",
        email: "rahul.sharma@example.com"
      },
      exam: {
        _id: query.examId || "6888abcd1234567890abcdef",
        examTitle: "Java Full Stack Recruitment Exam",
        examCode: "EXAM-JAVA-001",
        examDate: "2026-08-15"
      },
      score: {
        totalMarks: 80,
        obtainedMarks: 68,
        correctAnswers: 34,
        wrongAnswers: 4,
        unanswered: 2,
        percentage: 85
      },
      sectionWisePerformance: [
        {
          section: "Java",
          obtainedMarks: 36,
          totalMarks: 40,
          percentage: 90
        },
        {
          section: "Spring Boot",
          obtainedMarks: 32,
          totalMarks: 40,
          percentage: 80
        }
      ],
      result: {
        status: "PASS",
        grade: "A",
        rank: 12,
        percentile: 98.45,
        meritStatus: true
      },
      publishedBy: {
        _id: "6880employee1234567890abc",
        name: "Exam Manager"
      },
      publishedAt: "2026-08-15T12:15:00.000Z",
      certificateAvailable: true,
      resultPdf: "/results/EX20260001.pdf"
    };
  }
}

export const candidateExamService = new CandidateExamService();
