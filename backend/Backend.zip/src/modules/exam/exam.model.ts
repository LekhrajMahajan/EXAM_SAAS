import { Schema, model } from "mongoose";

import {
  IExam,
  ExamApprovalStatus,
  ExamStatus,
} from "./exam.types";

import { BaseSchemaFields } from "../../shared/base.schema";

/*
|--------------------------------------------------------------------------
| Exam Schema
|--------------------------------------------------------------------------
*/

const ExamSchema = new Schema<IExam>(
  {
    companyId: {
      type: Schema.Types.ObjectId,
      ref: "Company",
      required: true,
      index: true,
    },

    branchId: {
      type: Schema.Types.ObjectId,
      ref: "Branch",
      required: true,
      index: true,
    },

    centerId: {
      type: Schema.Types.ObjectId,
      ref: "Center",
      required: true,
      index: true,
    },

    shiftId: {
      type: Schema.Types.ObjectId,
      ref: "Shift",
      required: true,
      index: true,
    },

    subjectId: {
      type: Schema.Types.ObjectId,
      ref: "Subject",
      index: true,
    },

    paperId: {
      type: Schema.Types.ObjectId,
      ref: "Paper",
      index: true,
    },

    examCode: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },

    examTitle: {
      type: String,
      required: true,
      trim: true,
      maxlength: 200,
    },

    description: {
      type: String,
      default: "",
      trim: true,
      maxlength: 1000,
    },

    examDate: {
      type: Date,
      required: true,
    },

    startTime: {
      type: String,
      required: true,
      match: /^([01]\d|2[0-3]):([0-5]\d)$/,
    },

    endTime: {
      type: String,
      required: true,
      match: /^([01]\d|2[0-3]):([0-5]\d)$/,
    },

    duration: {
      type: Number,
      required: true,
      min: 1,
    },

    totalMarks: {
      type: Number,
      required: true,
      min: 0,
    },

    passingMarks: {
      type: Number,
      required: true,
      min: 0,
    },

    candidateIds: [
      {
        type: Schema.Types.ObjectId,
        ref: "Candidate",
      },
    ],

    securitySettings: {
      faceVerification: { type: Boolean, default: false },
      webcamMonitoring: { type: Boolean, default: false },
      screenRecording: { type: Boolean, default: false },
      screenSharingDetection: { type: Boolean, default: false },
      tabSwitchLimit: { type: Number, default: 0 },
      browserLock: { type: Boolean, default: false },
      fullScreenMode: { type: Boolean, default: false },
      copyPasteAllowed: { type: Boolean, default: false },
      rightClickDisabled: { type: Boolean, default: false },
      developerToolsBlocked: { type: Boolean, default: false },
      multipleLoginAllowed: { type: Boolean, default: false },
      geoFence: { type: Boolean, default: false },
      ipRestriction: { type: Boolean, default: false },
      candidateHeartbeat: { type: Boolean, default: false },
      autoSubmitOnViolation: { type: Boolean, default: false },
    },

    approvalStatus: {
      type: String,
      enum: Object.values(ExamApprovalStatus),
      default: ExamApprovalStatus.DRAFT,
      index: true,
    },

    status: {
      type: String,
      enum: Object.values(ExamStatus),
      default: ExamStatus.DRAFT,
      index: true,
    },

    startedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
    },

    startedAt: {
      type: Date,
    },

    startRemarks: {
      type: String,
    },

    endedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
    },

    endedAt: {
      type: Date,
    },

    endRemarks: {
      type: String,
    },

    isResultPublished: {
      type: Boolean,
      default: false,
    },

    resultPublishedAt: {
      type: Date,
    },

    resultPublishedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
    },

    resultPublishSettings: {
      publishType: { type: String },
      sendEmail: { type: Boolean, default: false },
      sendSMS: { type: Boolean, default: false },
      sendNotification: { type: Boolean, default: false },
      generateRank: { type: Boolean, default: false },
      generateMeritList: { type: Boolean, default: false },
      applyGraceMarks: { type: Boolean, default: false },
      publishRemarks: { type: String },
    },

    ...BaseSchemaFields,
  },
  {
    timestamps: true,
    versionKey: false,
  },
);

/*
|--------------------------------------------------------------------------
| Unique Index
|--------------------------------------------------------------------------
*/

ExamSchema.index(
  {
    companyId: 1,
    examCode: 1,
  },
  {
    unique: true,
  },
);

/*
|--------------------------------------------------------------------------
| Search Index
|--------------------------------------------------------------------------
*/

ExamSchema.index({
  examCode: "text",
  examTitle: "text",
  description: "text",
});

/*
|--------------------------------------------------------------------------
| Company Wise
|--------------------------------------------------------------------------
*/

ExamSchema.index({
  companyId: 1,
  status: 1,
});

/*
|--------------------------------------------------------------------------
| Subject Wise
|--------------------------------------------------------------------------
*/

ExamSchema.index({
  subjectId: 1,
  createdAt: -1,
});

/*
|--------------------------------------------------------------------------
| Exam Date
|--------------------------------------------------------------------------
*/

ExamSchema.index({
  examDate: 1,
});

/*
|--------------------------------------------------------------------------
| Soft Delete
|--------------------------------------------------------------------------
*/

ExamSchema.index({
  companyId: 1,
  isDeleted: 1,
});

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

const Exam = model<IExam>("Exam", ExamSchema);

export default Exam;
