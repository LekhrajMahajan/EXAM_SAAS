import companyService from "../company/company.service";
import subjectService from "../subject/subject.service";
import paperService from "../paper/paper.service";
import systemSettingsService from "../system-settings/systemSettings.service";
import { SettingCategory } from "../system-settings/systemSettings.types";

import examRepository from "./exam.repository";

import ApiError from "../../utils/ApiError";
import { HTTP_STATUS } from "../../constants/httpStatus";

import { ExamApprovalStatus, ExamStatus, IExam } from "./exam.types";
import { PaperApprovalStatus } from "../paper/paper.types";
import { BaseService } from "../../common/base.service";

class ExamService extends BaseService<IExam> {
  constructor() {
    super(examRepository, "Exam");
  }
  /*
  |--------------------------------------------------------------------------
  | Create Exam
  |--------------------------------------------------------------------------
  */

  async create(payload: Partial<IExam>) {
    await companyService.getActiveById(payload.companyId!.toString());
    await subjectService.getActiveById(payload.subjectId!.toString());
    const paper = await paperService.getActiveById(payload.paperId!.toString());

    // if (paper.approvalStatus !== PaperApprovalStatus.PUBLISHED) {
    //   throw new ApiError(
    //     HTTP_STATUS.BAD_REQUEST,
    //     "Only published papers can be assigned to an exam.",
    //   );
    // }

    const existingCode = await examRepository.findByExamCode(
      payload.companyId!.toString(),
      payload.examCode!,
    );

    if (existingCode) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Exam code already exists.");
    }

    const existingTitle = await examRepository.findByExamTitle(
      payload.companyId!.toString(),
      payload.examTitle!,
    );

    if (existingTitle) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Exam title already exists.");
    }

    // Dynamic settings validation
    const examSettingsRaw = await systemSettingsService.getByCategory(SettingCategory.EXAM);
    const examSettings = examSettingsRaw.reduce((acc: Record<string, any>, setting: any) => {
        acc[setting.key] = setting.value;
        return acc;
    }, {});

    const minDuration = examSettings.EXAM_MIN_DURATION ?? 15;
    const maxDuration = examSettings.EXAM_MAX_DURATION ?? 180;

    if (payload.duration && (payload.duration < minDuration || payload.duration > maxDuration)) {
        throw new ApiError(HTTP_STATUS.BAD_REQUEST, `Duration must be between ${minDuration} and ${maxDuration} minutes.`);
    }

    if (!payload.passingMarks && payload.totalMarks) {
        const passPercent = examSettings.EXAM_DEFAULT_PASSING_PERCENTAGE ?? 40;
        payload.passingMarks = (payload.totalMarks * passPercent) / 100;
    }

    // Set default security settings if not provided
    if (!payload.securitySettings) {
        payload.securitySettings = {
            faceVerification: examSettings.PROCTORING_FACE_VERIFICATION ?? false,
            webcamMonitoring: examSettings.PROCTORING_WEBCAM_MONITORING ?? false,
            screenRecording: examSettings.PROCTORING_SCREEN_RECORDING ?? false,
            screenSharingDetection: false,
            tabSwitchLimit: examSettings.PROCTORING_TAB_SWITCH_DETECTION ? 3 : 0,
            browserLock: examSettings.PROCTORING_BROWSER_LOCK ?? false,
            fullScreenMode: examSettings.PROCTORING_FULL_SCREEN ?? false,
            copyPasteAllowed: !(examSettings.PROCTORING_COPY_PASTE_BLOCK ?? true),
            rightClickDisabled: examSettings.PROCTORING_RIGHT_CLICK_BLOCK ?? true,
            developerToolsBlocked: true,
            multipleLoginAllowed: false,
            geoFence: false,
            ipRestriction: false,
            candidateHeartbeat: true,
            autoSubmitOnViolation: examSettings.SUBMISSION_AUTO_SUBMIT ?? false,
        };
    }

    return await super.create(payload);
  }



  /*
  |--------------------------------------------------------------------------
  | Update Exam
  |--------------------------------------------------------------------------
  */

  async update(id: string, payload: Partial<IExam>) {
    const exam = await super.getById(id);

    if (exam.approvalStatus === ExamApprovalStatus.PUBLISHED) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Published exam cannot be modified.",
      );
    }

    const companyId =
      (exam.companyId as any)._id?.toString() ?? exam.companyId.toString();

    if (payload.examCode && payload.examCode !== exam.examCode) {
      const exists = await examRepository.findByExamCode(
        companyId,
        payload.examCode,
      );

      if (exists) {
        throw new ApiError(HTTP_STATUS.CONFLICT, "Exam code already exists.");
      }
    }

    if (payload.examTitle && payload.examTitle !== exam.examTitle) {
      const exists = await examRepository.findByExamTitle(
        companyId,
        payload.examTitle,
      );

      if (exists) {
        throw new ApiError(HTTP_STATUS.CONFLICT, "Exam title already exists.");
      }
    }

    // Dynamic settings validation for updates
    if (payload.duration || payload.totalMarks || payload.passingMarks === undefined) {
        const examSettingsRaw = await systemSettingsService.getByCategory(SettingCategory.EXAM);
        const examSettings = examSettingsRaw.reduce((acc: Record<string, any>, setting: any) => {
            acc[setting.key] = setting.value;
            return acc;
        }, {});

        if (payload.duration) {
            const minDuration = examSettings.EXAM_MIN_DURATION ?? 15;
            const maxDuration = examSettings.EXAM_MAX_DURATION ?? 180;
            if (payload.duration < minDuration || payload.duration > maxDuration) {
                throw new ApiError(HTTP_STATUS.BAD_REQUEST, `Duration must be between ${minDuration} and ${maxDuration} minutes.`);
            }
        }
        
        // If they updated total marks but didn't pass passingMarks, we might want to recalculate
        // though normally passingMarks should be provided or kept as is.
    }

    return await super.update(id, payload);
  }



  /*
  |--------------------------------------------------------------------------
  | Get Preview
  |--------------------------------------------------------------------------
  */

  async getPreview(id: string) {
    const exam = await examRepository.getPreview(id);
    
    if (!exam) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Exam not found.");
    }

    let paperData = null;
    let questions: any[] = [];

    if (exam.paperId) {
      const paperIdStr = (exam.paperId as any)._id?.toString() || exam.paperId.toString();
      try {
        const paperPreview = await paperService.getPreview(paperIdStr);
        paperData = paperPreview.paper;
        questions = paperPreview.questions;
      } catch (error) {
        // If paper not found or errored, we can just ignore or log
      }
    }

    return {
      exam,
      paper: paperData,
      questions,
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Clone Exam
  |--------------------------------------------------------------------------
  */

  async clone(
    id: string,
    payload: {
      examTitle: string;
      examCode: string;
      examDate: Date;
      shiftId: string;
      copyCandidates: boolean;
      copySecuritysettings: boolean;
      copyPaper: boolean;
      status?: ExamStatus;
    }
  ) {
    const originalExam = await super.getById(id);
    const companyId = (originalExam.companyId as any)._id?.toString() ?? originalExam.companyId.toString();

    // Check for unique code and title
    const existingCode = await examRepository.findByExamCode(
      companyId,
      payload.examCode
    );

    if (existingCode) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Exam code already exists.");
    }

    const existingTitle = await examRepository.findByExamTitle(
      companyId,
      payload.examTitle
    );

    if (existingTitle) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Exam title already exists.");
    }

    // Prepare cloned data
    const cloneData: Partial<IExam> = {
      companyId: originalExam.companyId,
      branchId: originalExam.branchId,
      centerId: originalExam.centerId,
      shiftId: payload.shiftId as any,

      examCode: payload.examCode,
      examTitle: payload.examTitle,
      description: originalExam.description,
      examDate: payload.examDate,
      startTime: originalExam.startTime,
      endTime: originalExam.endTime,
      duration: originalExam.duration,
      totalMarks: originalExam.totalMarks,
      passingMarks: originalExam.passingMarks,

      status: payload.status || ExamStatus.DRAFT,
      approvalStatus: ExamApprovalStatus.DRAFT,

      candidateIds: payload.copyCandidates ? originalExam.candidateIds : [],
      
      securitySettings: payload.copySecuritysettings 
        ? originalExam.securitySettings 
        : {
            faceVerification: false,
            webcamMonitoring: false,
            screenRecording: false,
            screenSharingDetection: false,
            tabSwitchLimit: 0,
            browserLock: false,
            fullScreenMode: false,
            copyPasteAllowed: false,
            rightClickDisabled: false,
            developerToolsBlocked: false,
            multipleLoginAllowed: false,
            geoFence: false,
            ipRestriction: false,
            candidateHeartbeat: false,
            autoSubmitOnViolation: false,
          }
    };

    if (payload.copyPaper) {
      cloneData.subjectId = originalExam.subjectId;
      cloneData.paperId = originalExam.paperId;
    }

    return await super.create(cloneData);
  }



  /*
  |--------------------------------------------------------------------------
  | Update Approval
  |--------------------------------------------------------------------------
  */

  async updateApproval(id: string, approvalStatus: ExamApprovalStatus) {
    const exam = await super.getById(id);

    return await examRepository.updateApproval(id, approvalStatus);
  }
  /*
  |--------------------------------------------------------------------------
  | Submit For Approval
  |--------------------------------------------------------------------------
  */

  async submitForApproval(
    id: string,
    payload: { approvalStatus?: string; submittedBy?: string; remarks?: string },
  ) {
    const exam = await super.getById(id);
    const status = (payload.approvalStatus as ExamApprovalStatus) || ExamApprovalStatus.SUBMITTED;

    return await examRepository.updateApproval(id, status);
  }

  /*
  |--------------------------------------------------------------------------
  | Approve Exam
  |--------------------------------------------------------------------------
  */

  async approveExam(
    id: string,
    payload: { approvalStatus?: string; approvedBy?: string; approvalRemarks?: string },
  ) {
    const exam = await super.getById(id);
    const status = (payload.approvalStatus as ExamApprovalStatus) || ExamApprovalStatus.APPROVED;

    return await examRepository.updateApproval(id, status);
  }

  /*
  |--------------------------------------------------------------------------
  | Reject Exam
  |--------------------------------------------------------------------------
  */

  async rejectExam(
    id: string,
    payload: { approvalStatus?: string; rejectedBy?: string; rejectionReason?: string; rejectionRemarks?: string },
  ) {
    const exam = await super.getById(id);
    const status = (payload.approvalStatus as ExamApprovalStatus) || ExamApprovalStatus.REJECTED;

    return await examRepository.updateApproval(id, status);
  }

  /*
  |--------------------------------------------------------------------------
  | Start Exam
  |--------------------------------------------------------------------------
  */

  async startExam(
    id: string,
    payload: { startedBy: string; startRemarks?: string; forceStart?: boolean },
  ) {
    const exam = await super.getById(id);

    if (exam.status === ExamStatus.COMPLETED || exam.status === ExamStatus.CANCELLED) {
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "Cannot start a completed or cancelled exam.");
    }

    const validApprovalStatuses = [
      ExamApprovalStatus.APPROVED,
      ExamApprovalStatus.PUBLISHED,
    ];

    if (!payload.forceStart && !validApprovalStatuses.includes(exam.approvalStatus)) {
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "Only approved or published exams can be started unless force started.");
    }

    return await examRepository.update(id, {
      status: ExamStatus.ACTIVE,
      startedBy: payload.startedBy as any,
      startRemarks: payload.startRemarks,
      startedAt: new Date(),
    });
  }

  /*
  |--------------------------------------------------------------------------
  | End Exam
  |--------------------------------------------------------------------------
  */

  async endExam(
    id: string,
    payload: { endedBy: string; endRemarks?: string; forceEnd?: boolean },
  ) {
    const exam = await super.getById(id);

    if (exam.status !== ExamStatus.ACTIVE && !payload.forceEnd) {
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "Only active exams can be ended unless force ended.");
    }

    return await examRepository.update(id, {
      status: ExamStatus.COMPLETED,
      endedBy: payload.endedBy as any,
      endRemarks: payload.endRemarks,
      endedAt: new Date(),
    });
  }

  /*
  |--------------------------------------------------------------------------
  | Publish Exam Result
  |--------------------------------------------------------------------------
  */

  async publishResult(
    id: string,
    payload: {
      publishedBy: string;
      publishType: string;
      sendEmail: boolean;
      sendSMS: boolean;
      sendNotification: boolean;
      generateRank: boolean;
      generateMeritList: boolean;
      applyGraceMarks: boolean;
      publishRemarks?: string;
    },
  ) {
    const exam = await super.getById(id);

    if (exam.status !== ExamStatus.COMPLETED) {
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "Only completed exams can have their results published.");
    }

    return await examRepository.update(id, {
      isResultPublished: true,
      resultPublishedAt: new Date(),
      resultPublishedBy: payload.publishedBy as any,
      resultPublishSettings: {
        publishType: payload.publishType,
        sendEmail: payload.sendEmail,
        sendSMS: payload.sendSMS,
        sendNotification: payload.sendNotification,
        generateRank: payload.generateRank,
        generateMeritList: payload.generateMeritList,
        applyGraceMarks: payload.applyGraceMarks,
        publishRemarks: payload.publishRemarks,
      },
    });
  }
  /*
  |--------------------------------------------------------------------------
  | Statistics
  |--------------------------------------------------------------------------
  */

  async statistics(companyId?: string) {
    const totalExams = await examRepository.count(companyId);

    const activeExams = await examRepository.countByStatus(
      ExamStatus.ACTIVE,
      companyId,
    );

    const completedExams = await examRepository.countByStatus(
      ExamStatus.COMPLETED,
      companyId,
    );

    const cancelledExams = await examRepository.countByStatus(
      ExamStatus.CANCELLED,
      companyId,
    );

    const draftExams = await examRepository.countByApproval(
      ExamApprovalStatus.DRAFT,
      companyId,
    );

    const approvedExams = await examRepository.countByApproval(
      ExamApprovalStatus.APPROVED,
      companyId,
    );

    const publishedExams = await examRepository.countByApproval(
      ExamApprovalStatus.PUBLISHED,
      companyId,
    );

    return {
      totalExams,
      activeExams,
      completedExams,
      cancelledExams,
      draftExams,
      approvedExams,
      publishedExams,
    };
  }
}

export default new ExamService();
