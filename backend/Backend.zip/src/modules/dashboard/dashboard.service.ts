import {
    DashboardPeriod,
    IDashboardFilter,
    IDashboardCharts,
} from "./dashboard.types";
import Company from "../company/company.model";
import User from "../auth/user.model";
import Role from "../role/role.model";
import Permission from "../permission/permission.model";
import Payment from "../payment/payment.model";
import SupportTicket from "../support-ticket/supportTicket.model";


class DashboardService {

    /*
    |--------------------------------------------------------------------------
    | Dashboard Overview
    |--------------------------------------------------------------------------
    */

    async getOverview(
        filter: IDashboardFilter
    ) {
        // Fetch actual system counts
        const totalCandidates = await User.countDocuments({ role: { $ne: "MASTER_ADMIN" } });
        const activeCompanies = await Company.countDocuments({ status: true });
        const totalCompanies = await Company.countDocuments();
        const pendingCompanies = await Company.countDocuments({ status: false });
        const suspendedCompanies = 0; // Model only supports boolean status currently
        
        const totalUsers = await User.countDocuments();
        const totalRoles = await Role.countDocuments();
        const totalPermissions = await Permission.countDocuments();
        
        // Dynamic stats
        const now = new Date();
        const activeSubscriptions = await Company.countDocuments({ 
            subscriptionEndDate: { $gt: now },
            status: true
        });
        const expiredSubscriptions = await Company.countDocuments({ 
            subscriptionEndDate: { $lte: now }
        });
        
        const openSupportTickets = await SupportTicket.countDocuments({ status: "OPEN" });

        // Calculate Revenue
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        
        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);

        const [todaysRevenueResult, monthlyRevenueResult] = await Promise.all([
            Payment.aggregate([
                { $match: { status: "SUCCESS", createdAt: { $gte: startOfDay } } },
                { $group: { _id: null, total: { $sum: "$amount" } } }
            ]),
            Payment.aggregate([
                { $match: { status: "SUCCESS", createdAt: { $gte: startOfMonth } } },
                { $group: { _id: null, total: { $sum: "$amount" } } }
            ])
        ]);

        const todaysRevenue = todaysRevenueResult[0]?.total || 0;
        const monthlyRevenue = monthlyRevenueResult[0]?.total || 0;
        
        return {
            period: filter.period ?? DashboardPeriod.TODAY,
            totalCandidates,
            totalExams: 0,
            totalResults: 0,
            totalAttendance: 0,
            activeExams: 0,
            
            // Master Admin stats
            companies: totalCompanies,
            activeCompanies,
            pendingCompanies,
            suspendedCompanies,
            totalUsers,
            totalRoles,
            totalPermissions,
            activeSubscriptions,
            expiredSubscriptions,
            todaysRevenue,
            monthlyRevenue,
            openSupportTickets
        };
    }

    async getDashboardCharts(filter: IDashboardFilter): Promise<IDashboardCharts> {
        // 1. Company Status Distribution
        const companyStatusCounts = await Company.aggregate([
            { $group: { _id: "$status", count: { $sum: 1 } } }
        ]);
        const activeCount = companyStatusCounts.find(c => c._id === true)?.count || 0;
        const pendingCount = companyStatusCounts.find(c => c._id === false)?.count || 0;
        
        // 2. Company Growth (Current Year by Month)
        const currentYear = new Date().getFullYear();
        const companyGrowthAgg = await Company.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: new Date(`${currentYear}-01-01`),
                        $lte: new Date(`${currentYear}-12-31T23:59:59.999Z`)
                    }
                }
            },
            {
                $group: {
                    _id: { $month: "$createdAt" },
                    count: { $sum: 1 }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        const allMonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        let cumulative = 0;
        const growthData = allMonths.map((_, index) => {
            const monthData = companyGrowthAgg.find(m => m._id === index + 1);
            cumulative += (monthData?.count || 0);
            return cumulative;
        });

        // 3. Revenue Trend (Current Week by Day)
        const today = new Date();
        const currentDayOfWeek = today.getDay(); // 0 is Sunday, 1 is Monday...
        const diff = today.getDate() - currentDayOfWeek + (currentDayOfWeek === 0 ? -6 : 1); // Monday
        const startOfWeek = new Date(today.setDate(diff));
        startOfWeek.setHours(0,0,0,0);
        
        const revenueAgg = await Payment.aggregate([
            {
                $match: {
                    status: "SUCCESS",
                    createdAt: { $gte: startOfWeek }
                }
            },
            {
                $group: {
                    _id: { $dayOfWeek: "$createdAt" }, // 1 is Sunday, 2 is Monday
                    total: { $sum: "$amount" }
                }
            }
        ]);
        
        const weekLabels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
        const revenueData = [2, 3, 4, 5, 6, 7, 1].map(day => {
            return revenueAgg.find(r => r._id === day)?.total || 0;
        });

        return {
            companyGrowth: {
                labels: allMonths,
                series: [{ name: "Companies", data: growthData }]
            },
            subscriptionTrend: {
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
                series: [
                    { name: "Basic Plan", data: [20, 25, 35, 40, 45, 55, 60] },
                    { name: "Pro Plan", data: [5, 10, 15, 25, 35, 45, 50] },
                    { name: "Enterprise", data: [1, 2, 2, 4, 5, 8, 12] }
                ]
            },
            revenueTrend: {
                labels: weekLabels,
                series: [{ name: "Revenue ($)", data: revenueData }]
            },
            companyStatusDistribution: {
                labels: ["Active", "Pending", "Suspended", "Inactive"],
                series: [{ name: "Status", data: [activeCount, pendingCount, 0, 0] }]
            }
        };
    }

    /*
    |--------------------------------------------------------------------------
    | Dashboard Cards
    |--------------------------------------------------------------------------
    */

    async getDashboardCards(
        filter: IDashboardFilter
    ) {

        return [

            {

                title:
                    "Candidates",

                value: 0,

            },

            {

                title:
                    "Exams",

                value: 0,

            },

            {

                title:
                    "Results",

                value: 0,

            },

            {

                title:
                    "Attendance",

                value: 0,

            },

        ];

    }

    /*
    |--------------------------------------------------------------------------
    | Exam Statistics
    |--------------------------------------------------------------------------
    */

    async getExamStatistics(
        filter: IDashboardFilter
    ) {

        return {

            total: 0,

            scheduled: 0,

            ongoing: 0,

            completed: 0,

            cancelled: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Candidate Statistics
    |--------------------------------------------------------------------------
    */

    async getCandidateStatistics(
        filter: IDashboardFilter
    ) {

        return {

            total: 0,

            registered: 0,

            verified: 0,

            blocked: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Result Statistics
    |--------------------------------------------------------------------------
    */

    async getResultStatistics(
        filter: IDashboardFilter
    ) {

        return {

            total: 0,

            passed: 0,

            failed: 0,

            passPercentage: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Attendance Statistics
    |--------------------------------------------------------------------------
    */

    async getAttendanceStatistics(
        filter: IDashboardFilter
    ) {

        return {

            present: 0,

            absent: 0,

            attendancePercentage: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Live Monitoring Statistics
    |--------------------------------------------------------------------------
    */

    async getLiveMonitoringStatistics(
        filter: IDashboardFilter
    ) {

        return {

            activeCandidates: 0,

            warnings: 0,

            violations: 0,

            disconnected: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Question Bank Statistics
    |--------------------------------------------------------------------------
    */

    async getQuestionBankStatistics(
        filter: IDashboardFilter
    ) {

        return {

            subjects: 0,

            chapters: 0,

            topics: 0,

            questions: 0,

            papers: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Company Statistics
    |--------------------------------------------------------------------------
    */

    async getCompanyStatistics(
        filter: IDashboardFilter
    ) {

        return {

            companies: 0,

            activeCompanies: 0,

            inactiveCompanies: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Center Statistics
    |--------------------------------------------------------------------------
    */

    async getCenterStatistics(
        filter: IDashboardFilter
    ) {

        return {

            totalCenters: 0,

            activeCenters: 0,

            inactiveCenters: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Employee Statistics
    |--------------------------------------------------------------------------
    */

    async getEmployeeStatistics(
        filter: IDashboardFilter
    ) {

        return {

            totalEmployees: 0,

            activeEmployees: 0,

            inactiveEmployees: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Activity Statistics
    |--------------------------------------------------------------------------
    */

    async getActivityStatistics(
        filter: IDashboardFilter
    ) {

        return {

            todayActivities: 0,

            loginActivities: 0,

            examActivities: 0,

            systemActivities: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Queue Statistics
    |--------------------------------------------------------------------------
    */

    async getQueueStatistics(
        filter: IDashboardFilter
    ) {

        return {

            waiting: 0,

            active: 0,

            completed: 0,

            failed: 0,

            delayed: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Notification Statistics
    |--------------------------------------------------------------------------
    */

    async getNotificationStatistics(
        filter: IDashboardFilter
    ) {

        return {

            emails: 0,

            sms: 0,

            pushNotifications: 0,

            unread: 0,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | System Health
    |--------------------------------------------------------------------------
    */

    async getSystemHealth() {

        return {

            server: "Healthy",

            database: "Connected",

            redis: "Connected",

            queue: "Running",

            storage: "Available",

            uptime: process.uptime(),

            memoryUsage: process.memoryUsage(),

            nodeVersion: process.version,

        };

    }

}

export default new DashboardService();
