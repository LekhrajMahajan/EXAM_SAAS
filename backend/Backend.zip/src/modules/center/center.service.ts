import { Types } from "mongoose";
import crypto from "crypto";
import centerRepository from "./center.repository";
import companyService from "../company/company.service";
import branchService from "../branch/branch.service";
import authService from "../auth/auth.service";
import emailService from "../email/email.service";
import auditLogService from "../audit-log/auditLog.service";

import ApiError from "../../utils/ApiError";
import { HTTP_STATUS } from "../../constants/httpStatus";

import {
  ICenter,
  CenterStatus,
  CenterSetupStatus,
  DocumentApprovalStatus,
  ICenterDashboardStats,
  ICenterDocumentUpload,
} from "./center.types";
import { BaseService } from "../../common/base.service";
import { AuditAction } from "../audit-log/auditLog.types";

class CenterService extends BaseService<ICenter> {
  constructor() {
    super(centerRepository, "Center");
  }

  /*
  |--------------------------------------------------------------------------
  | Create Center with Automatic Center Manager Provisioning (Phase 5.3)
  |--------------------------------------------------------------------------
  */
  async create(payload: Partial<ICenter>) {
    await companyService.getActiveById(payload.companyId!.toString());
    const branch = await branchService.getActiveById(payload.branchId!.toString());

    const branchCompanyId = (branch.companyId as any)._id
      ? (branch.companyId as any)._id.toString()
      : branch.companyId.toString();

    if (branchCompanyId !== payload.companyId!.toString()) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Branch does not belong to the selected company.",
      );
    }

    const existingCode = await centerRepository.findByCenterCode(
      payload.companyId!.toString(),
      payload.branchId!.toString(),
      payload.centerCode!,
    );

    if (existingCode) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Center code already exists.");
    }

    const existingName = await centerRepository.findByCenterName(
      payload.companyId!.toString(),
      payload.branchId!.toString(),
      payload.centerName!,
    );

    if (existingName) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Center name already exists.");
    }

    if (payload.availableCapacity! > payload.capacity!) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Available capacity cannot exceed total capacity.",
      );
    }

    // Set initial onboarding status
    payload.setupStatus = CenterSetupStatus.DRAFT;
    payload.setupCurrentStep = 1;
    payload.completionPercentage = 0;
    payload.readinessScore = 0;
    payload.complianceScore = 0;

    // Set mandatory documents boilerplate if none supplied
    if (!payload.documents || payload.documents.length === 0) {
      payload.documents = [
        { documentType: "PAN Card", isMandatory: true, fileName: "Pending Upload", fileUrl: "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
        { documentType: "GST Certificate", isMandatory: true, fileName: "Pending Upload", fileUrl: "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
        { documentType: "Aadhaar Card", isMandatory: true, fileName: "Pending Upload", fileUrl: "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
        { documentType: "Cancelled Cheque", isMandatory: true, fileName: "Pending Upload", fileUrl: "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
        { documentType: "Signed MOU", isMandatory: true, fileName: payload.mouPdfUrl ? "Initial MOU" : "Pending Upload", fileUrl: payload.mouPdfUrl || "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
        { documentType: "Electricity Bill", isMandatory: true, fileName: "Pending Upload", fileUrl: "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
        { documentType: "Fire NOC", isMandatory: true, fileName: "Pending Upload", fileUrl: "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
        { documentType: "Building Safety Certificate", isMandatory: true, fileName: "Pending Upload", fileUrl: "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
        { documentType: "Internet Provider Letter", isMandatory: true, fileName: "Pending Upload", fileUrl: "", version: 1, status: DocumentApprovalStatus.PENDING, uploadedAt: new Date() },
      ];
    }

    const center: any = await super.create(payload);
    const centerIdStr = center._id || center.id;

    // Auto-provision Center Manager user account if official email is provided
    if (center.email) {
      try {
        let managerUser: any = await authService.checkEmailExists(center.email);
        let temporaryPassword = "";

        if (!managerUser) {
          // Generate secure temporary password (e.g. Ctr@8b1a3eA1!)
          const randomHex = crypto.randomBytes(4).toString("hex");
          temporaryPassword = `Ctr@${randomHex}B2!`;

          managerUser = await authService.createUser({
            companyId: center.companyId,
            branchId: center.branchId,
            centerId: new Types.ObjectId(centerIdStr.toString()),
            firstName: center.managerName || "Center",
            lastName: "Manager",
            email: center.email,
            phone: center.phone || "0000000000",
            password: temporaryPassword,
            role: "CENTER_MANAGER",
            forcePasswordChange: true,
            department: "Center Operations & Administration",
            designation: "Center Head / Manager",
            status: "ACTIVE",
          } as any);
        }

        // Assign manager to center
        const managerId = (managerUser as any)._id || (managerUser as any).id;
        if (managerId) {
          await centerRepository.update(centerIdStr.toString(), {
            centerManagerId: new Types.ObjectId(managerId.toString()),
          } as any);
          (center as any).centerManagerId = managerId;
        }

        // Dispatch login credentials email via email Service
        if (temporaryPassword) {
          await emailService
            .send({
              to: center.email,
              subject: `Center Manager Login Credentials - ${center.centerName}`,
              html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px;">
                  <h2 style="color: #059669; margin-top: 0;">Welcome to ExamGuard Pro Enterprise</h2>
                  <p>Hello <strong>${center.managerName || "Center Manager"}</strong>,</p>
                  <p>A new examination center <strong>${center.centerName} (${center.centerCode})</strong> has been registered, and your user profile has been provisioned as the designated Center Manager.</p>
                  <div style="background: #f0fdf4; padding: 15px; border-radius: 6px; border-left: 4px solid #10b981; margin: 20px 0;">
                    <p style="margin: 0 0 10px 0;"><strong>Your Secure Login Credentials:</strong></p>
                    <p style="margin: 5px 0;"><b>Official Email:</b> ${center.email}</p>
                    <p style="margin: 5px 0;"><b>Temporary Password:</b> <code style="background: #d1fae5; padding: 2px 6px; border-radius: 4px; color: #065f46; font-weight: bold;">${temporaryPassword}</code></p>
                    <p style="margin: 5px 0;"><b>Assigned Role:</b> CENTER_MANAGER</p>
                    <p style="margin: 5px 0;"><b>Login Portal:</b> /auth/login</p>
                  </div>
                  <p style="color: #dc2626; font-weight: bold;">⚠️ Mandatory Security Compliance:</p>
                  <p style="color: #4b5563;">Upon initial authentication, you must complete a forced password rotation. Furthermore, operational dashboard access is strictly locked until you complete all 8 stages of the <b>Center Setup & Verification Wizard</b> and obtain Company Admin verification.</p>
                </div>
              `,
            })
            .catch((err) => {
              console.warn(`Failed to send Center Manager onboarding email: ${err.message}`);
            });
        }
      } catch (err: any) {
        console.warn(`Center Manager auto-provisioning exception during center creation: ${err.message}`);
      }
    }

    // Record system audit log
    await auditLogService.log({
      action: AuditAction.CREATE,
      module: "Center Operation Workflow",
      targetId: centerIdStr.toString(),
      description: `Created center ${center.centerName} with commercial agreement and provisioned manager account.`,
      status: "SUCCESS",
    } as any).catch(() => {});

    return center;
  }

  /*
  |--------------------------------------------------------------------------
  | Save Onboarding Step (Steps 1 through 8)
  |--------------------------------------------------------------------------
  */
  async saveOnboardingStep(
    centerId: string,
    step: number,
    stepPayload: any,
    reqUser?: any,
    reqMetadata?: { ip?: string; userAgent?: string }
  ) {
    const center = await centerRepository.findById(centerId);
    if (!center) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Center record not found.");
    }

    if (center.setupStatus === CenterSetupStatus.ACTIVE) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Center verification is already ACTIVE. Operational modifications must use enterprise settings."
      );
    }

    const updateFields: Partial<ICenter> = {};

    // Step 1: Rules & Agreement Acceptance
    if (step === 1) {
      updateFields.agreementDetails = {
        acceptedBy: reqUser?.email || center.email,
        acceptedTime: new Date(),
        acceptedIp: reqMetadata?.ip || "127.0.0.1",
        browser: reqMetadata?.userAgent || "Automated Enterprise Client",
        device: "Web Browser Desktop/Mobile",
        geoLocation: {
          latitude: center.latitude || 28.6139,
          longitude: center.longitude || 77.209,
          city: center.city || "Headquarters Area",
        },
      };
    }
    // Step 2: Center Profile Extension
    else if (step === 2) {
      updateFields.profileExtension = {
        ...center.profileExtension,
        ...stepPayload,
      };
      if (stepPayload.latitude !== undefined) updateFields.latitude = stepPayload.latitude;
      if (stepPayload.longitude !== undefined) updateFields.longitude = stepPayload.longitude;
    }
    // Step 3: Document Uploads & Versioning
    else if (step === 3) {
      const currentDocs: ICenterDocumentUpload[] = Array.isArray(center.documents) ? [...center.documents] : [];
      const newDocs: ICenterDocumentUpload[] = Array.isArray(stepPayload.documents) ? stepPayload.documents : [];

      newDocs.forEach((inDoc) => {
        const existingIdx = currentDocs.findIndex(
          (d) => d.documentType.toLowerCase() === inDoc.documentType.toLowerCase()
        );
        if (existingIdx !== -1) {
          // Keep version history or increment version if replaced
          const existingDoc = currentDocs[existingIdx];
          const newVersion = existingDoc.fileUrl !== inDoc.fileUrl ? (existingDoc.version || 1) + 1 : existingDoc.version || 1;
          currentDocs[existingIdx] = {
            ...existingDoc,
            fileName: inDoc.fileName || existingDoc.fileName,
            fileUrl: inDoc.fileUrl || existingDoc.fileUrl,
            expiryDate: inDoc.expiryDate || existingDoc.expiryDate,
            version: newVersion,
            status: existingDoc.status === DocumentApprovalStatus.REJECTED ? DocumentApprovalStatus.PENDING : existingDoc.status,
            uploadedAt: new Date(),
          };
        } else {
          currentDocs.push({
            documentType: inDoc.documentType,
            isMandatory: inDoc.isMandatory !== undefined ? inDoc.isMandatory : false,
            fileName: inDoc.fileName,
            fileUrl: inDoc.fileUrl,
            version: 1,
            status: DocumentApprovalStatus.PENDING,
            uploadedAt: new Date(),
          });
        }
      });
      updateFields.documents = currentDocs;
    }
    // Step 4: Center Staff Registration with auto Employee ID generation
    else if (step === 4) {
      const staffList = Array.isArray(stepPayload.staffList) ? stepPayload.staffList : [];
      updateFields.staffList = staffList.map((s: any, idx: number) => ({
        ...s,
        employeeId: s.employeeId || `${center.centerCode}_STF_${String(idx + 1).padStart(3, "0")}`,
        joiningDate: s.joiningDate ? new Date(s.joiningDate) : new Date(),
        employeeStatus: s.employeeStatus || "ACTIVE",
      }));
    }
    // Step 5: Infrastructure Setup
    else if (step === 5) {
      const infra = Array.isArray(stepPayload.infrastructureNodes) ? stepPayload.infrastructureNodes : [];
      updateFields.infrastructureNodes = infra;
    }
    // Step 6: Exam Readiness Score calculation
    else if (step === 6) {
      const readiness = stepPayload.examReadiness || {};
      let score = 0;
      if (readiness.hasControlRoom) score += 20;
      if (readiness.hasStrongRoom) score += 25;
      if (readiness.hasQuestionPaperStorage) score += 15;
      if ((readiness.biometricCountersCount || 0) >= 4) score += 15;
      if (readiness.powerBackupTested) score += 15;
      if (readiness.internetBackupTested) score += 10;

      updateFields.examReadiness = { ...readiness, readinessScore: Math.min(score, 100) };
      updateFields.readinessScore = Math.min(score, 100);
    }
    // Step 7: Center Capacity & Shift Planning Validation
    else if (step === 7) {
      const plans = Array.isArray(stepPayload.shiftPlans) ? stepPayload.shiftPlans : [];
      // Validate whether sufficient infrastructure exists
      const totalSystems = (center.infrastructureNodes || []).reduce((acc: number, cur: any) => acc + (cur.computerCount || 0), 0);
      
      updateFields.shiftPlans = plans.map((p: any) => {
        const isInfraValid = totalSystems === 0 || totalSystems >= (p.maximumCandidates || 0);
        // Match expected revenue against shift commercial agreement if defined
        let expectedRevenue = p.expectedRevenue || 0;
        const commAgreement = (center.commercialAgreement || []).find((c: any) => c.shiftName === p.shiftName);
        if (commAgreement && !p.expectedRevenue) {
          expectedRevenue = (p.maximumCandidates || 0) * (commAgreement.pricePerCandidate || 350);
        }

        return {
          ...p,
          isInfrastructureValid: isInfraValid,
          expectedRevenue,
        };
      });
    }
    // Step 8: Center Compliance Checklist
    else if (step === 8) {
      const comp = stepPayload.complianceChecklist || {};
      let cScore = 0;
      if (comp.fireSafetyTested) cScore += 15;
      if (comp.biometricTested) cScore += 15;
      if (comp.cctvWorking) cScore += 15;
      if (comp.networkTested) cScore += 15;
      if (comp.powerBackupTested) cScore += 10;
      if (comp.computersTested) cScore += 10;
      if (comp.strongRoomReady) cScore += 10;
      if (comp.questionStorageReady) cScore += 10;

      const finalizedScore = Math.min(cScore, 100);
      updateFields.complianceChecklist = { ...comp, complianceScore: finalizedScore };
      updateFields.complianceScore = finalizedScore;
    }

    // Update progression trackers
    const newStep = Math.max(center.setupCurrentStep || 1, step >= 8 ? 8 : step + 1);
    updateFields.setupCurrentStep = newStep;
    updateFields.completionPercentage = Math.round((newStep / 8) * 100);

    if (center.setupStatus === CenterSetupStatus.REJECTED && step === 8) {
      updateFields.setupStatus = CenterSetupStatus.DRAFT;
    }

    const updated = await centerRepository.update(centerId, updateFields as any);

    await auditLogService.log({
      action: AuditAction.UPDATE,
      module: "Center Onboarding Wizard",
      targetId: centerId,
      description: `Center Manager saved onboarding Step ${step} for ${center.centerName}`,
      performedBy: reqUser?.id || reqUser?.userId,
      performedByRole: reqUser?.role || "CENTER_MANAGER",
      status: "SUCCESS",
    } as any).catch(() => {});

    return updated;
  }

  /*
  |--------------------------------------------------------------------------
  | Submit Onboarding for Admin Verification
  |--------------------------------------------------------------------------
  */
  async submitForVerification(centerId: string, reqUser?: any) {
    const center = await centerRepository.findById(centerId);
    if (!center) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Center record not found.");
    }

    if (center.setupStatus === CenterSetupStatus.ACTIVE) {
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "Center is already active and verified.");
    }

    // Validate minimum requirements before submitting
    if ((center.setupCurrentStep || 1) < 8 && (center.completionPercentage || 0) < 90) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Cannot submit verification: You must complete all 8 mandatory steps of the onboarding workflow."
      );
    }

    const updated = await centerRepository.update(centerId, {
      setupStatus: CenterSetupStatus.PENDING_VERIFICATION,
      completionPercentage: 100,
      adminReviewRemarks: "",
    } as any);

    await auditLogService.log({
      action: AuditAction.UPDATE,
      module: "Center Verification Workflow",
      targetId: centerId,
      description: `Center Manager submitted onboarding setup for official administrative verification.`,
      performedBy: reqUser?.id || reqUser?.userId,
      performedByRole: reqUser?.role || "CENTER_MANAGER",
      status: "SUCCESS",
    } as any).catch(() => {});

    return updated;
  }

  /*
  |--------------------------------------------------------------------------
  | Verify Document (Company Admin Action)
  |--------------------------------------------------------------------------
  */
  async verifyDocument(
    centerId: string,
    documentIdOrType: string,
    status: DocumentApprovalStatus,
    rejectionReason?: string,
    correctionNotes?: string,
    reqUser?: any
  ) {
    const center = await centerRepository.findById(centerId);
    if (!center) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Center record not found.");
    }

    if (status === DocumentApprovalStatus.REJECTED && (!rejectionReason || !rejectionReason.trim())) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Rejection Reason and Correction Notes are strictly required when rejecting a center legal document."
      );
    }

    const documents: any[] = Array.isArray(center.documents) ? [...center.documents] : [];
    const docIdx = documents.findIndex(
      (d) => d._id?.toString() === documentIdOrType || d.documentType?.toLowerCase() === documentIdOrType.toLowerCase()
    );

    if (docIdx === -1) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Target document upload not found in center profile.");
    }

    documents[docIdx] = {
      ...documents[docIdx],
      status,
      rejectionReason: status === DocumentApprovalStatus.REJECTED ? rejectionReason : "",
      correctionNotes: status === DocumentApprovalStatus.REJECTED ? correctionNotes : "",
    };

    const updated = await centerRepository.update(centerId, { documents } as any);

    await auditLogService.log({
      action: AuditAction.UPDATE,
      module: "Document Approval Workflow",
      targetId: centerId,
      description: `Company Admin set document (${documents[docIdx].documentType}) to status ${status}.`,
      performedBy: reqUser?.id || reqUser?.userId,
      performedByRole: reqUser?.role || "COMPANY_ADMIN",
      status: "SUCCESS",
    } as any).catch(() => {});

    return updated;
  }

  /*
  |--------------------------------------------------------------------------
  | Verify Center Setup (Company Admin Approval / Rejection)
  |--------------------------------------------------------------------------
  */
  async verifyCenterSetup(centerId: string, status: CenterSetupStatus, remarks?: string, reqUser?: any) {
    const center = await centerRepository.findById(centerId);
    if (!center) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Center record not found.");
    }

    if (status === CenterSetupStatus.REJECTED && (!remarks || !remarks.trim())) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Explicit revision feedback remarks are mandatory when rejecting a center onboarding setup."
      );
    }

    // Verify all mandatory documents are approved before activating
    if (status === CenterSetupStatus.ACTIVE) {
      const mandatoryDocs = (center.documents || []).filter((d: any) => d.isMandatory);
      const unapproved = mandatoryDocs.filter((d: any) => d.status !== DocumentApprovalStatus.APPROVED && d.fileUrl && d.fileUrl.trim() !== "");
      if (unapproved.length > 0) {
        throw new ApiError(
          HTTP_STATUS.BAD_REQUEST,
          `Cannot verify center as ACTIVE: Mandatory documents (${unapproved.map((u: any) => u.documentType).join(", ")}) must be explicitly approved first.`
        );
      }
    }

    const updateFields: any = {
      setupStatus: status,
      adminReviewRemarks: status === CenterSetupStatus.REJECTED ? remarks : "Approved and activated by Company Admin",
    };

    if (status === CenterSetupStatus.ACTIVE) {
      updateFields.status = CenterStatus.ACTIVE;
      updateFields.completionPercentage = 100;
    }

    const updated = await centerRepository.update(centerId, updateFields);

    await auditLogService.log({
      action: AuditAction.UPDATE,
      module: "Center Verification Workflow",
      targetId: centerId,
      description: `Company Admin finalized center verification decision: ${status} for ${center.centerName}`,
      performedBy: reqUser?.id || reqUser?.userId,
      performedByRole: reqUser?.role || "COMPANY_ADMIN",
      status: "SUCCESS",
    } as any).catch(() => {});

    return updated;
  }

  /*
  |--------------------------------------------------------------------------
  | Get Pending Verifications List
  |--------------------------------------------------------------------------
  */
  async getPendingVerifications(companyId?: string, branchId?: string) {
    const centers = await centerRepository.findPendingVerifications(companyId, branchId);
    return {
      centers,
      total: centers.length,
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Get Center Dashboard Analytics & Readiness
  |--------------------------------------------------------------------------
  */
  async getCenterDashboardStats(centerId: string) {
    const stats = await centerRepository.getDashboardStats(centerId);
    if (!stats) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Center statistics could not be compiled.");
    }
    return stats;
  }

  /*
  |--------------------------------------------------------------------------
  | Get All Centers (Existing CRUD preserved)
  |--------------------------------------------------------------------------
  */
  async getAll(query: any) {
    const result = await super.getAll(query);
    return {
      centers: result.data,
      total: result.total,
      page: result.page,
      limit: result.limit,
      totalPages: result.totalPages,
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Update Center (Existing CRUD preserved)
  |--------------------------------------------------------------------------
  */
  async update(id: string, payload: Partial<ICenter>) {
    const center = await centerRepository.findById(id);

    if (!center) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Center not found.");
    }

    if (payload.centerCode && payload.centerCode !== center.centerCode) {
      const existingCode = await centerRepository.findByCenterCode(
        center.companyId._id.toString(),
        center.branchId._id.toString(),
        payload.centerCode,
      );

      if (existingCode && existingCode.id !== id) {
        throw new ApiError(HTTP_STATUS.CONFLICT, "Center code already exists.");
      }
    }

    if (payload.centerName && payload.centerName !== center.centerName) {
      const existingName = await centerRepository.findByCenterName(
        center.companyId._id.toString(),
        center.branchId._id.toString(),
        payload.centerName,
      );

      if (existingName && existingName.id !== id) {
        throw new ApiError(HTTP_STATUS.CONFLICT, "Center name already exists.");
      }
    }

    const totalCapacity = payload.capacity ?? center.capacity;
    const availableCapacity = payload.availableCapacity ?? center.availableCapacity;

    if (availableCapacity > totalCapacity) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Available capacity cannot exceed total capacity.",
      );
    }

    return await super.update(id, payload);
  }

  /*
  |--------------------------------------------------------------------------
  | Statistics
  |--------------------------------------------------------------------------
  */
  async statistics(companyId?: string) {
    const totalCenters = await centerRepository.count(companyId ? { companyId } : undefined);
    return {
      totalCenters,
    };
  }
}

export default new CenterService();
