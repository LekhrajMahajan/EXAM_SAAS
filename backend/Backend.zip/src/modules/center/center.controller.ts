import { Request, Response } from "express";

import centerService from "./center.service";

import { asyncHandler } from "../../utils/asyncHandler";
import { sendResponse } from "../../utils/response";
import { HTTP_STATUS } from "../../constants/httpStatus";

/*
|--------------------------------------------------------------------------
| Create Center
|--------------------------------------------------------------------------
*/

export const createCenter = asyncHandler(
  async (req: Request, res: Response) => {
    const result = await centerService.create(req.body);

    return sendResponse(res, HTTP_STATUS.CREATED, {
      success: true,
      message: "Center created successfully.",
      data: result,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Get All Centers
|--------------------------------------------------------------------------
*/

export const getCenters = asyncHandler(async (req: Request, res: Response) => {
  const result = await centerService.getAll({
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 10,
    search: req.query.search as string,
    companyId: req.query.companyId as string,
    branchId: req.query.branchId as string,
    city: req.query.city as string,
    state: req.query.state as string,
    centerType: req.query.centerType as string,
    status: req.query.status as string,
  });

  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Centers fetched successfully.",
    data: result,
  });
});

/*
|--------------------------------------------------------------------------
| Get Center By Id
|--------------------------------------------------------------------------
*/

export const getCenterById = asyncHandler(
  async (req: Request, res: Response) => {
    const result = await centerService.getById(req.params.id as string);

    return sendResponse(res, HTTP_STATUS.OK, {
      success: true,
      message: "Center fetched successfully.",
      data: result,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Update Center
|--------------------------------------------------------------------------
*/

export const updateCenter = asyncHandler(
  async (req: Request, res: Response) => {
    const result = await centerService.update(
      req.params.id as string,
      req.body,
    );

    return sendResponse(res, HTTP_STATUS.OK, {
      success: true,
      message: "Center updated successfully.",
      data: result,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Update Center Status
|--------------------------------------------------------------------------
*/

export const updateCenterStatus = asyncHandler(
  async (req: Request, res: Response) => {
    const result = await centerService.updateStatus(
      req.params.id as string,
      req.body.status,
    );

    return sendResponse(res, HTTP_STATUS.OK, {
      success: true,
      message: "Center status updated successfully.",
      data: result,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Delete Center
|--------------------------------------------------------------------------
*/

export const deleteCenter = asyncHandler(
  async (req: Request, res: Response) => {
    const result = await centerService.delete(req.params.id as string);

    return sendResponse(res, HTTP_STATUS.OK, {
      success: true,
      message: "Center deleted successfully.",
      data: result,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Restore Center
|--------------------------------------------------------------------------
*/

export const restoreCenter = asyncHandler(
  async (req: Request, res: Response) => {
    const result = await centerService.restore(req.params.id as string);

    return sendResponse(res, HTTP_STATUS.OK, {
      success: true,
      message: "Center restored successfully.",
      data: result,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Center Statistics
|--------------------------------------------------------------------------
*/

export const getCenterStatistics = asyncHandler(
  async (req: Request, res: Response) => {
    const result = await centerService.statistics(
      req.query.companyId as string,
    );

    return sendResponse(res, HTTP_STATUS.OK, {
      success: true,
      message: "Center statistics fetched successfully.",
      data: result,
    });
  },
);

/*
|--------------------------------------------------------------------------
| Phase 5.3: Center Onboarding & Verification Handlers
|--------------------------------------------------------------------------
*/

const resolveCenterId = (req: any): string => {
  if (req.query.centerId && typeof req.query.centerId === "string") {
    return req.query.centerId;
  }
  if (req.params.centerId && typeof req.params.centerId === "string") {
    return req.params.centerId;
  }
  if (req.user?.centerId) {
    return req.user.centerId.toString();
  }
  return req.params.id as string;
};

export const startOnboarding = asyncHandler(async (req: Request, res: Response) => {
  const centerId = resolveCenterId(req);
  const center = await centerService.getById(centerId);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center onboarding setup started.",
    data: center,
  });
});

export const saveOnboardingAgreement = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const ip = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "127.0.0.1";
  const userAgent = req.headers["user-agent"] || "Enterprise Client";
  const result = await centerService.saveOnboardingStep(centerId, 1, req.body, req.user, { ip: String(ip), userAgent });
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Onboarding agreement signed successfully.",
    data: result,
  });
});

export const saveOnboardingProfile = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const result = await centerService.saveOnboardingStep(centerId, 2, req.body, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center profile information saved successfully.",
    data: result,
  });
});

export const saveOnboardingDocuments = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const result = await centerService.saveOnboardingStep(centerId, 3, req.body, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center documents uploaded successfully.",
    data: result,
  });
});

export const saveOnboardingStaff = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const result = await centerService.saveOnboardingStep(centerId, 4, req.body, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center staff registered successfully.",
    data: result,
  });
});

export const saveOnboardingInfrastructure = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const result = await centerService.saveOnboardingStep(centerId, 5, req.body, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center infrastructure configured successfully.",
    data: result,
  });
});

export const saveOnboardingShiftPlanning = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const result = await centerService.saveOnboardingStep(centerId, 7, req.body, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Shift planning and capacity allocations saved successfully.",
    data: result,
  });
});

export const saveOnboardingCompliance = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const result = await centerService.saveOnboardingStep(centerId, 8, req.body, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center compliance testing recorded successfully.",
    data: result,
  });
});

export const submitOnboarding = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const result = await centerService.submitForVerification(centerId, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center onboarding setup submitted for Company Admin verification.",
    data: result,
  });
});

export const getOnboardingStatus = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const center = await centerService.getById(centerId);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center onboarding status fetched.",
    data: {
      setupStatus: center.setupStatus || "DRAFT",
      setupCurrentStep: center.setupCurrentStep || 1,
      completionPercentage: center.completionPercentage || 0,
      readinessScore: center.readinessScore || 0,
      complianceScore: center.complianceScore || 0,
      adminReviewRemarks: center.adminReviewRemarks || "",
      documents: center.documents || [],
    },
  });
});

export const getCenterDashboard = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const result = await centerService.getCenterDashboardStats(centerId);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center dashboard metrics generated successfully.",
    data: result,
  });
});

export const getCenterReadiness = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const center: any = await centerService.getById(centerId);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center readiness checklist fetched.",
    data: {
      readinessScore: center.readinessScore || 0,
      examReadiness: center.examReadiness || {},
      infrastructureCount: (center.infrastructureNodes || []).length,
    },
  });
});

export const getCenterCompliance = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const center: any = await centerService.getById(centerId);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Center compliance details fetched.",
    data: {
      complianceScore: center.complianceScore || 0,
      complianceChecklist: center.complianceChecklist || {},
      verificationStatus: center.setupStatus || "DRAFT",
    },
  });
});

export const getCommercialAgreement = asyncHandler(async (req: any, res: Response) => {
  const centerId = resolveCenterId(req);
  const center: any = await centerService.getById(centerId);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Shift-wise commercial agreement fetched.",
    data: {
      mouPdfUrl: center.mouPdfUrl || "",
      commercialAgreement: center.commercialAgreement || [],
      agreementDetails: center.agreementDetails || null,
    },
  });
});

export const getPendingVerifications = asyncHandler(async (req: any, res: Response) => {
  const result = await centerService.getPendingVerifications(req.query.companyId as string, req.query.branchId as string);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Pending center verifications fetched successfully.",
    data: result,
  });
});

export const approveDocument = asyncHandler(async (req: any, res: Response) => {
  const centerId = req.query.centerId ? String(req.query.centerId) : resolveCenterId(req);
  const result = await centerService.verifyDocument(centerId, req.params.id, "APPROVED" as any, undefined, undefined, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Document approved successfully.",
    data: result,
  });
});

export const rejectDocument = asyncHandler(async (req: any, res: Response) => {
  const centerId = req.query.centerId ? String(req.query.centerId) : resolveCenterId(req);
  const { rejectionReason, correctionNotes } = req.body;
  const result = await centerService.verifyDocument(centerId, req.params.id, "REJECTED" as any, rejectionReason, correctionNotes, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: "Document rejected with feedback notes.",
    data: result,
  });
});

export const verifyCenterSetup = asyncHandler(async (req: any, res: Response) => {
  const centerId = req.params.id || req.body.centerId || resolveCenterId(req);
  const { status, remarks } = req.body;
  const result = await centerService.verifyCenterSetup(centerId, status, remarks, req.user);
  return sendResponse(res, HTTP_STATUS.OK, {
    success: true,
    message: `Center verification completed: ${status}`,
    data: result,
  });
});

