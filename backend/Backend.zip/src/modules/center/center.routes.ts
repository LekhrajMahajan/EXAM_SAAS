import { Router } from "express";

import {
  createCenter,
  getCenters,
  getCenterById,
  updateCenter,
  updateCenterStatus,
  deleteCenter,
  restoreCenter,
  getCenterStatistics,
  startOnboarding,
  saveOnboardingAgreement,
  saveOnboardingProfile,
  saveOnboardingDocuments,
  saveOnboardingStaff,
  saveOnboardingInfrastructure,
  saveOnboardingShiftPlanning,
  saveOnboardingCompliance,
  submitOnboarding,
  getOnboardingStatus,
  getCenterDashboard,
  getCenterReadiness,
  getCenterCompliance,
  getCommercialAgreement,
  getPendingVerifications,
  approveDocument,
  rejectDocument,
  verifyCenterSetup,
} from "./center.controller";

import { authenticate } from "../../middleware/authenticate";
import { authorize } from "../../middleware/authorize";
import { validate } from "../../middleware/validate";
import { checkUsageLimit } from "../../middleware/checkUsageLimit";
import Center from "./center.model";
import { UserRole } from "../../constants/roles";

import {
  createCenterSchema,
  updateCenterSchema,
  updateCenterStatusSchema,
  saveOnboardingStepSchema,
  verifyDocumentSchema,
  verifyCenterSetupSchema,
} from "./center.validation";

const router = Router();

/*
|--------------------------------------------------------------------------
| Statistics & Pending Verifications
|--------------------------------------------------------------------------
*/

router.get(
  "/statistics",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  getCenterStatistics,
);

router.get(
  "/pending-verifications",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  getPendingVerifications,
);

/*
|--------------------------------------------------------------------------
| Center Dashboard Analytics & Operations (Phase 5.3)
|--------------------------------------------------------------------------
*/

router.get(
  "/dashboard",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER, UserRole.CENTER_MANAGER),
  getCenterDashboard,
);

router.get(
  "/readiness",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER, UserRole.CENTER_MANAGER),
  getCenterReadiness,
);

router.get(
  "/compliance",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER, UserRole.CENTER_MANAGER),
  getCenterCompliance,
);

router.get(
  "/commercial-agreement",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER, UserRole.CENTER_MANAGER),
  getCommercialAgreement,
);

/*
|--------------------------------------------------------------------------
| Center Manager Onboarding Wizard Routes (Phase 5.3)
|--------------------------------------------------------------------------
*/

router.post(
  "/onboarding/start",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  startOnboarding,
);

router.get(
  "/onboarding/status",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  getOnboardingStatus,
);

router.put(
  "/onboarding/agreement",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(saveOnboardingStepSchema),
  saveOnboardingAgreement,
);

router.put(
  "/onboarding/profile",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(saveOnboardingStepSchema),
  saveOnboardingProfile,
);

router.put(
  "/onboarding/documents",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(saveOnboardingStepSchema),
  saveOnboardingDocuments,
);

router.put(
  "/onboarding/staff",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(saveOnboardingStepSchema),
  saveOnboardingStaff,
);

router.put(
  "/onboarding/infrastructure",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(saveOnboardingStepSchema),
  saveOnboardingInfrastructure,
);

router.put(
  "/onboarding/shift-planning",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(saveOnboardingStepSchema),
  saveOnboardingShiftPlanning,
);

router.put(
  "/onboarding/compliance",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(saveOnboardingStepSchema),
  saveOnboardingCompliance,
);

router.post(
  "/onboarding/submit",
  authenticate,
  authorize(UserRole.CENTER_MANAGER, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  submitOnboarding,
);

/*
|--------------------------------------------------------------------------
| Document Approval Workflow & Center Verification (Company Admin)
|--------------------------------------------------------------------------
*/

router.patch(
  "/documents/:id/approve",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN),
  approveDocument,
);

router.patch(
  "/documents/:id/reject",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN),
  validate(verifyDocumentSchema),
  rejectDocument,
);

router.patch(
  "/:id/verify",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN),
  validate(verifyCenterSetupSchema),
  verifyCenterSetup,
);

/*
|--------------------------------------------------------------------------
| Standard CRUD Routes
|--------------------------------------------------------------------------
*/

router.post(
  "/",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(createCenterSchema),
  checkUsageLimit("maxCenters", Center),
  createCenter,
);

router.get(
  "/",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER, UserRole.CENTER_MANAGER),
  getCenters,
);

router.get(
  "/:id",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER, UserRole.CENTER_MANAGER),
  getCenterById,
);

router.patch(
  "/:id",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BRANCH_MANAGER),
  validate(updateCenterSchema),
  updateCenter,
);

router.patch(
  "/:id/status",
  authenticate,
  authorize(UserRole.MASTER_ADMIN, UserRole.COMPANY_ADMIN),
  validate(updateCenterStatusSchema),
  updateCenterStatus,
);

router.patch(
  "/:id/restore",
  authenticate,
  authorize(UserRole.MASTER_ADMIN),
  restoreCenter,
);

router.delete(
  "/:id",
  authenticate,
  authorize(UserRole.MASTER_ADMIN),
  deleteCenter,
);

export default router;
