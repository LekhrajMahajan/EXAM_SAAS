import mongoose, { ClientSession } from "mongoose";

import ApiError from "../../utils/ApiError";
import { HTTP_STATUS } from "../../constants/httpStatus";

import attendanceService from "../attendance/attendance.service";
import examSubmissionService from "../exam-submission/examSubmission.service";
import candidateAnswerService from "../candidate-answer/candidateAnswer.service";
import paperService from "../paper/paper.service";
import paperQuestionService from "../paper-question/paperQuestion.service";
import questionService from "../question-bank/question.service";

import resultRepository, {
    ResultQuery,
} from "./result.repository";

import {
    IResult,
    ResultStatus,
    PassStatus,
    EvaluationMethod,
} from "./result.types";

import { BaseService } from "../../common/base.service";

import ExamSubmission from "../exam-submission/examSubmission.model";
import CandidateAnswer from "../candidate-answer/candidateAnswer.model";
import Question from "../question-bank/question.model";
import Paper from "../paper/paper.model";
import Result from "./result.model";
import { SubmissionStatus } from "../exam-submission/examSubmission.types";

class ResultService extends BaseService<IResult> {
    constructor() {
        super(resultRepository, "Result");
    }



    /*
    |--------------------------------------------------------------------------
    | Validate Submission
    |--------------------------------------------------------------------------
    */

    private async validateSubmission(
        submissionId: string
    ) {

        return examSubmissionService.getById(
            submissionId
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Validate Attendance
    |--------------------------------------------------------------------------
    */

    private async validateAttendance(
        attendanceId: string
    ) {

        return attendanceService.getById(
            attendanceId
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Create Result
    |--------------------------------------------------------------------------
    */

    async create(
        payload: Partial<IResult>
    ) {

        if (payload.attendanceId) {
            await this.validateAttendance(
                payload.attendanceId.toString()
            );
        }

        if (payload.submissionId) {
            await this.validateSubmission(
                payload.submissionId.toString()
            );
        }

        try {

            const result =
                await super.create(

                    {

                        ...payload,

                        attemptedQuestions: payload.attemptedQuestions ?? 0,

                        correctAnswers: payload.correctAnswers ?? 0,

                        wrongAnswers: payload.wrongAnswers ?? 0,

                        unansweredQuestions:
                            payload.unansweredQuestions ?? payload.totalQuestions ?? 0,

                        marksObtained: payload.marksObtained ?? 0,

                        negativeMarks: payload.negativeMarks ?? 0,

                        percentage: payload.percentage ?? 0,

                        passStatus:
                            payload.passStatus ?? PassStatus.FAILED,

                        resultStatus:
                            payload.resultStatus ?? ResultStatus.DRAFT,

                        evaluationMethod:
                            payload.evaluationMethod ?? EvaluationMethod.AUTO,

                        evaluationVersion: payload.evaluationVersion ?? 1,

                    }

                );

            return result;

        } catch (error) {

            throw error;

        }

    }



    /*
    |--------------------------------------------------------------------------
    | Get By Candidate
    |--------------------------------------------------------------------------
    */

    async getByCandidate(
        candidateId: string
    ) {

        return resultRepository.findByCandidate(
            candidateId
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Get By Exam
    |--------------------------------------------------------------------------
    */

    async getByExam(
        examId: string
    ) {

        return resultRepository.findByExam(
            examId
        );

    }



    /*
    |--------------------------------------------------------------------------
    | Evaluate Result
    |--------------------------------------------------------------------------
    */

    async evaluate(
        resultId: string
    ) {

        const result =
            await super.getById(
                resultId
            );

        /*
        |--------------------------------------------------------------------------
        | Load Candidate Answers
        |--------------------------------------------------------------------------
        */

        const candidateAnswers =
            await candidateAnswerService.getSubmissionAnswers(
                result.submissionId.toString()
            );

        if (!candidateAnswers.length) {

            throw new ApiError(

                HTTP_STATUS.BAD_REQUEST,

                "Candidate answers not found."

            );

        }

        /*
        |--------------------------------------------------------------------------
        | Load Paper Questions
        |--------------------------------------------------------------------------
        */

        const paperQuestions =
            await paperQuestionService.getByPaper(
                result.paperId.toString()
            );

        if (!paperQuestions.length) {

            throw new ApiError(

                HTTP_STATUS.BAD_REQUEST,

                "Paper questions not found."

            );

        }

        /*
        |--------------------------------------------------------------------------
        | Evaluation Variables
        |--------------------------------------------------------------------------
        */

        let attemptedQuestions = 0;

        let correctAnswers = 0;

        let wrongAnswers = 0;

        let unansweredQuestions = 0;

        let obtainedMarks = 0;

        let negativeMarks = 0;

        /*
        |--------------------------------------------------------------------------
        | Evaluate Every Question
        |--------------------------------------------------------------------------
        */

        for (const paperQuestion of paperQuestions) {

            const answer =
                candidateAnswers.find(

                    candidateAnswer =>

                        candidateAnswer.questionId.toString() ===

                        paperQuestion.questionId.toString()

                );

            if (!answer || !answer.isAnswered) {

                unansweredQuestions++;

                continue;

            }

            attemptedQuestions++;

            const question =
                await questionService.getById(
                    paperQuestion.questionId.toString()
                );

            const evaluation =
                this.evaluateAnswer(
                    answer,
                    question,
                    paperQuestion
                );

            if (evaluation.correct) {

                correctAnswers++;

                obtainedMarks +=
                    evaluation.marks;

            } else {

                wrongAnswers++;

                negativeMarks +=
                    evaluation.negativeMarks;

            }

        }

        /*
        |--------------------------------------------------------------------------
        | Final Marks
        |--------------------------------------------------------------------------
        */

        obtainedMarks =
            obtainedMarks - negativeMarks;

        if (obtainedMarks < 0) {

            obtainedMarks = 0;

        }

        const percentage =
            this.calculatePercentage(

                obtainedMarks,

                result.totalMarks

            );

        const passStatus =
            this.calculatePassStatus(

                obtainedMarks,

                result.passingMarks

            );

        return super.update(

            resultId,

            {

                attemptedQuestions,

                correctAnswers,

                wrongAnswers,

                unansweredQuestions,

                marksObtained: obtainedMarks,

                negativeMarks,

                percentage,

                passStatus,

                resultStatus:
                    ResultStatus.EVALUATED,

                evaluatedAt:
                    new Date(),

            }

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Evaluate Single Answer
    |--------------------------------------------------------------------------
    */

    private evaluateAnswer(

        answer: any,

        question: any,

        paperQuestion: any

    ) {

        let correct = false;

        switch (

            question.questionType

        ) {

            case "SINGLE_CHOICE":

                correct =

                    answer.selectedOption ===

                    question.correctAnswer[0];

                break;

            case "MULTIPLE_CHOICE":

                correct =

                    JSON.stringify(

                        [

                            ...(answer.selectedOptions || [])

                        ].sort()

                    ) ===

                    JSON.stringify(

                        [

                            ...question.correctAnswer

                        ].sort()

                    );

                break;

            case "TRUE_FALSE":

                correct =

                    answer.selectedOption ===

                    question.correctAnswer[0];

                break;

            case "NUMERICAL":

                correct =

                    Number(

                        answer.numericalAnswer

                    ) ===

                    Number(

                        question.correctAnswer[0]

                    );

                break;

            default:

                correct = false;

        }

        return {

            correct,

            marks:

                correct

                    ? paperQuestion.marks

                    : 0,

            negativeMarks:

                correct

                    ? 0

                    : paperQuestion.negativeMarks,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Calculate Percentage
    |--------------------------------------------------------------------------
    */

    private calculatePercentage(

        obtainedMarks: number,

        totalMarks: number

    ): number {

        if (totalMarks <= 0) {

            return 0;

        }

        return Number(

            (

                (obtainedMarks / totalMarks) * 100

            ).toFixed(2)

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Calculate Pass Status
    |--------------------------------------------------------------------------
    */

    private calculatePassStatus(

        obtainedMarks: number,

        passingMarks: number

    ): PassStatus {

        return obtainedMarks >= passingMarks

            ? PassStatus.PASSED

            : PassStatus.FAILED;

    }

    /*
    |--------------------------------------------------------------------------
    | Publish Result
    |--------------------------------------------------------------------------
    */

    async publish(

        resultId: string,

        publishedBy: string

    ) {

        const result =
            await super.getById(resultId);

        if (

            result.resultStatus !==
            ResultStatus.EVALUATED

        ) {

            throw new ApiError(

                HTTP_STATUS.BAD_REQUEST,

                "Only evaluated results can be published."

            );

        }

        return super.update(

            resultId,

            {

                resultStatus:
                    ResultStatus.PUBLISHED,

                publishedBy: new mongoose.Types.ObjectId(publishedBy) as any,

                publishedAt: new Date(),

            }

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Approve Result
    |--------------------------------------------------------------------------
    */

    async approve(

        resultId: string,

        approvedBy: string

    ) {

        const result =
            await super.getById(resultId);

        if (

            result.resultStatus !==
            ResultStatus.PUBLISHED

        ) {

            throw new ApiError(

                HTTP_STATUS.BAD_REQUEST,

                "Result must be published first."

            );

        }

        return super.update(

            resultId,

            {

                resultStatus:
                    ResultStatus.APPROVED,

                approvedBy: new mongoose.Types.ObjectId(approvedBy) as any,

                approvedAt: new Date(),

            }

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Reject Result
    |--------------------------------------------------------------------------
    */

    async reject(

        resultId: string,

        remarks: string

    ) {

        const result =
            await super.getById(resultId);

        if (

            result.resultStatus ===
            ResultStatus.APPROVED

        ) {

            throw new ApiError(

                HTTP_STATUS.BAD_REQUEST,

                "Approved result cannot be rejected."

            );

        }

        return super.update(

            resultId,

            {

                resultStatus:
                    ResultStatus.REJECTED,

                remarks,

            }

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Re-Evaluate
    |--------------------------------------------------------------------------
    */

    async reEvaluate(
        resultId: string
    ) {

        const result =
            await super.getById(
                resultId
            );

        await super.update(

            resultId,

            {

                evaluationVersion:

                    result.evaluationVersion + 1,

                resultStatus:

                    ResultStatus.DRAFT,

            }

        );

        return this.evaluate(
            resultId
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Generate Rank
    |--------------------------------------------------------------------------
    */

    async generateRank(
        examId: string
    ) {

        const results =
            await resultRepository.findByExam(
                examId
            );

        if (!results.length) {

            return [];

        }

        /*
        |--------------------------------------------------------------------------
        | Sort
        |--------------------------------------------------------------------------
        */

        const sorted = [...results].sort(

            (a, b) => {

                if (
                    b.marksObtained !==
                    a.marksObtained
                ) {

                    return (
                        b.marksObtained -
                        a.marksObtained
                    );

                }

                if (
                    b.correctAnswers !==
                    a.correctAnswers
                ) {

                    return (
                        b.correctAnswers -
                        a.correctAnswers
                    );

                }

                return (
                    a.negativeMarks -
                    b.negativeMarks
                );

            }

        );

        /*
        |--------------------------------------------------------------------------
        | Assign Rank
        |--------------------------------------------------------------------------
        */

        let currentRank = 1;

        for (

            let index = 0;

            index < sorted.length;

            index++

        ) {

            if (index > 0) {

                const previous =
                    sorted[index - 1];

                const current =
                    sorted[index];

                const isTie =

                    previous.marksObtained ===
                        current.marksObtained &&

                    previous.correctAnswers ===
                        current.correctAnswers &&

                    previous.negativeMarks ===
                        current.negativeMarks;

                if (!isTie) {

                    currentRank =
                        index + 1;

                }

            }

            await super.update(

                sorted[index]._id.toString(),

                {

                    rank: currentRank,

                }

            );

        }

        return sorted;

    }

    /*
    |--------------------------------------------------------------------------
    | Generate Results
    |--------------------------------------------------------------------------
    */

    async generateResults(payload: any) {
        const { examId, generatedBy } = payload;
        
        // 1. Find all submitted candidates for the exam
        const submissions = await ExamSubmission.find({
            examId,
            submissionStatus: { $in: [SubmissionStatus.SUBMITTED, SubmissionStatus.AUTO_SUBMITTED] }
        });

        if (!submissions.length) {
            return {
                generated: false,
                examId,
                generatedBy,
                message: "No submitted candidates found for evaluation."
            };
        }

        let generatedCount = 0;

        // 2. Loop through each submission
        for (const submission of submissions) {
            // Check if result already exists to prevent duplicates if not forceRegenerate
            if (!payload.forceRegenerate) {
                const existingResult = await Result.findOne({ examId, candidateId: submission.candidateId });
                if (existingResult) continue;
            }

            // Fetch answers for this candidate
            const answers = await CandidateAnswer.find({
                examId,
                candidateId: submission.candidateId
            });

            let correct = 0;
            let wrong = 0;
            let skipped = 0;
            let obtainedMarks = 0;
            let negativeMarks = 0;

            // Evaluate each answer
            for (const answer of answers) {
                if (!answer.isAnswered) {
                    skipped++;
                    continue;
                }

                const question = await Question.findById(answer.questionId);
                if (!question) {
                    skipped++;
                    continue;
                }

                const marksForQuestion = question.marks || 1;
                const penaltyForQuestion = payload.negativeMarking ? (question.negativeMarks || 0) : 0;
                
                let isCorrect = false;

                // Compare based on question type
                if (question.questionType === "SINGLE_CHOICE" || question.questionType === "TRUE_FALSE") {
                    if (question.correctAnswer.includes(answer.selectedOption || "")) {
                        isCorrect = true;
                    }
                } else if (question.questionType === "MULTIPLE_CHOICE") {
                    const correctAns = question.correctAnswer.sort().join(",");
                    const selectedAns = (answer.selectedOptions || []).sort().join(",");
                    if (correctAns === selectedAns && correctAns.length > 0) {
                        isCorrect = true;
                    }
                }

                if (isCorrect) {
                    correct++;
                    obtainedMarks += marksForQuestion;
                } else {
                    wrong++;
                    negativeMarks += penaltyForQuestion;
                }
            }

            const paper = await Paper.findById(submission.paperId);
            if (!paper) {
                skipped += answers.length;
                continue; // Skip if paper not found
            }

            // Calculate final scores
            const finalMarks = Math.max(0, obtainedMarks - negativeMarks);
            const totalMarks = paper.totalMarks || 100;
            const percentage = (finalMarks / totalMarks) * 100;
            
            let grade = "F";
            if (percentage >= 90) grade = "A+";
            else if (percentage >= 80) grade = "A";
            else if (percentage >= 70) grade = "B";
            else if (percentage >= 60) grade = "C";
            else if (percentage >= 50) grade = "D";

            const resultStatus = percentage >= (paper.passingMarks || 35) ? PassStatus.PASSED : PassStatus.FAILED;

            // Create Result
            await Result.create({
                attendanceId: submission.attendanceId,
                submissionId: submission._id,
                candidateId: submission.candidateId,
                candidateAssignmentId: submission.candidateAssignmentId,
                examId: submission.examId,
                paperId: submission.paperId,
                subjectId: submission.subjectId,
                companyId: submission.companyId,
                branchId: submission.branchId,
                examCenterId: submission.examCenterId,
                examRoomId: submission.examRoomId,
                totalQuestions: submission.totalQuestions,
                attemptedQuestions: correct + wrong,
                correctAnswers: correct,
                wrongAnswers: wrong,
                unansweredQuestions: skipped,
                totalMarks: totalMarks,
                marksObtained: finalMarks,
                negativeMarks: negativeMarks,
                passingMarks: paper.passingMarks || 35,
                percentage,
                passStatus: resultStatus,
                resultStatus: ResultStatus.EVALUATED,
                evaluationMethod: EvaluationMethod.AUTO,
                generatedBy,
                createdBy: generatedBy
            });
            
            generatedCount++;
        }

        return {
            generated: true,
            examId,
            generatedCount,
            generatedBy
        };
    }

    async updateMany(filter: any, update: any) {
        return Result.updateMany(filter, update);
    }

    /*
    |--------------------------------------------------------------------------
    | Dashboard
    |--------------------------------------------------------------------------
    */

    async dashboard(
        examId?: string
    ) {

        const [

            total,

            passed,

            failed,

        ] = await Promise.all([

            resultRepository.count(
                examId
            ),

            resultRepository.countPassed(
                examId
            ),

            resultRepository.countFailed(
                examId
            ),

        ]);

        return {

            total,

            passed,

            failed,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Statistics
    |--------------------------------------------------------------------------
    */

    async statistics(
        examId?: string
    ) {

        const dashboard =
            await this.dashboard(
                examId
            );

        const percentage =
            dashboard.total === 0

                ? 0

                : Number(

                      (

                          (dashboard.passed /

                              dashboard.total) *

                          100

                      ).toFixed(2)

                  );

        return {

            ...dashboard,

            passPercentage:
                percentage,

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Pass Percentage
    |--------------------------------------------------------------------------
    */

    async passPercentage(
        examId: string
    ) {

        const total =
            await resultRepository.count(
                examId
            );

        const passed =
            await resultRepository.countPassed(
                examId
            );

        return {

            total,

            passed,

            percentage:

                total === 0

                    ? 0

                    : Number(

                          (

                              (passed / total) *

                              100

                          ).toFixed(2)

                      ),

        };

    }

    /*
    |--------------------------------------------------------------------------
    | Merit List
    |--------------------------------------------------------------------------
    */

    async meritList(
        examId: string,
        limit = 100
    ) {

        const results =
            await resultRepository.findByExam(
                examId
            );

        return results

            .filter(

                result =>

                    result.resultStatus ===
                    ResultStatus.APPROVED

            )

            .sort(

                (a, b) => {

                    if (
                        b.marksObtained !==
                        a.marksObtained
                    ) {

                        return (
                            b.marksObtained -
                            a.marksObtained
                        );

                    }

                    return (
                        a.rank ?? 999999
                    ) -

                    (
                        b.rank ?? 999999
                    );

                }

            )

            .slice(0, limit);

    }

    /*
    |--------------------------------------------------------------------------
    | Topper
    |--------------------------------------------------------------------------
    */

    async topper(
        examId: string
    ) {

        const meritList =
            await this.meritList(
                examId,
                1
            );

        return meritList.length

            ? meritList[0]

            : null;

    }

    async softDelete(
        resultId: string
    ) {
        return super.delete(resultId);
    }



    /*
    |--------------------------------------------------------------------------
    | Delete Permanently
    |--------------------------------------------------------------------------
    */

    async permanentDelete(
        resultId: string
    ) {

        await super.getById(
            resultId
        );

        return resultRepository.permanentDelete(
            resultId
        );

    }

}

export default new ResultService();
