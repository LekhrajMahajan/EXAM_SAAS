import companyService from "../company/company.service";
import subjectService from "../subject/subject.service";

import paperRepository from "./paper.repository";
import paperQuestionRepository from "../paper-question/paperQuestion.repository";

import ApiError from "../../utils/ApiError";
import { HTTP_STATUS } from "../../constants/httpStatus";

import { IPaper, PaperApprovalStatus, PaperStatus } from "./paper.types";
import { BaseService } from "../../common/base.service";

class PaperService extends BaseService<IPaper> {
  constructor() {
    super(paperRepository, "Paper");
  }
  /*
  |--------------------------------------------------------------------------
  | Create Paper
  |--------------------------------------------------------------------------
  */

  async create(payload: Partial<IPaper>) {
    await companyService.getActiveById(payload.companyId!.toString());
    await subjectService.getActiveById(payload.subjectId!.toString());

    const existingCode = await paperRepository.findByPaperCode(
      payload.companyId!.toString(),
      payload.paperCode!,
    );

    if (existingCode) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Paper code already exists.");
    }

    const existingName = await paperRepository.findByPaperName(
      payload.companyId!.toString(),
      payload.subjectId!.toString(),
      payload.paperName!,
    );

    if (existingName) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Paper name already exists.");
    }

    return await super.create(payload);
  }



  /*
  |--------------------------------------------------------------------------
  | Update Paper
  |--------------------------------------------------------------------------
  */

  async update(id: string, payload: Partial<IPaper>) {
    const paper = await super.getById(id);

    if (paper.approvalStatus === PaperApprovalStatus.PUBLISHED) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Published paper cannot be edited.",
      );
    }

    const companyId =
      (paper.companyId as any)._id?.toString() ?? paper.companyId.toString();

    const subjectId =
      (paper.subjectId as any)._id?.toString() ?? paper.subjectId.toString();

    if (payload.paperCode && payload.paperCode !== paper.paperCode) {
      const exists = await paperRepository.findByPaperCode(
        companyId,
        payload.paperCode,
      );

      if (exists) {
        throw new ApiError(HTTP_STATUS.CONFLICT, "Paper code already exists.");
      }
    }

    if (payload.paperName && payload.paperName !== paper.paperName) {
      const exists = await paperRepository.findByPaperName(
        companyId,
        subjectId,
        payload.paperName,
      );

      if (exists) {
        throw new ApiError(HTTP_STATUS.CONFLICT, "Paper name already exists.");
      }
    }

    return await super.update(id, payload);
  }

  /*
  |--------------------------------------------------------------------------
  | Get Preview
  |--------------------------------------------------------------------------
  */

  async getPreview(id: string) {
    const paper = await super.getById(id);
    const questions = await paperQuestionRepository.findByPaperId(id);

    return {
      paper,
      questions,
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Clone Paper
  |--------------------------------------------------------------------------
  */

  async clone(
    id: string,
    payload: {
      paperName: string;
      paperCode: string;
      copyQuestions?: boolean;
      copyInstructions?: boolean;
      copySettings?: boolean;
      approvalStatus?: PaperApprovalStatus;
    },
  ) {
    const original = await paperRepository.findById(id);

    if (!original) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Original paper not found.");
    }

    const companyIdStr = (original.companyId as any)._id?.toString() || original.companyId.toString();
    const subjectIdStr = (original.subjectId as any)._id?.toString() || original.subjectId.toString();

    const existingCode = await paperRepository.findByPaperCode(
      companyIdStr,
      payload.paperCode,
    );

    if (existingCode) {
      throw new ApiError(HTTP_STATUS.CONFLICT, "Paper code already exists.");
    }

    const newPaperData: Partial<IPaper> = {
      companyId: companyIdStr as any,
      subjectId: subjectIdStr as any,
      paperName: payload.paperName,
      paperCode: payload.paperCode,
      description: original.description,
      
      // Settings
      duration: payload.copySettings ? original.duration : 60,
      totalQuestions: original.totalQuestions,
      totalMarks: original.totalMarks,
      passingMarks: payload.copySettings ? original.passingMarks : 0,
      negativeMarking: payload.copySettings ? original.negativeMarking : false,
      negativeMarks: payload.copySettings ? original.negativeMarks : 0,
      shuffleQuestions: payload.copySettings ? original.shuffleQuestions : false,
      shuffleOptions: payload.copySettings ? original.shuffleOptions : false,
      
      // Instructions
      instructions: payload.copyInstructions ? original.instructions : [],
      
      // Sections
      sections: original.sections.map(sec => ({
        sectionCode: sec.sectionCode,
        sectionName: sec.sectionName,
        instructions: payload.copyInstructions ? sec.instructions : "",
        totalQuestions: sec.totalQuestions,
        totalMarks: sec.totalMarks,
        optionalQuestions: sec.optionalQuestions,
        displayOrder: sec.displayOrder
      })),

      approvalStatus: payload.approvalStatus || PaperApprovalStatus.DRAFT,
      status: PaperStatus.INACTIVE,
    };

    const newPaper = await paperRepository.create(newPaperData);

    if (payload.copyQuestions) {
      const originalQuestions = await paperQuestionRepository.findByPaperId(id);
      
      if (originalQuestions.length > 0) {
        const clonedQuestions = originalQuestions.map((oq: any) => ({
          paperId: newPaper._id as any,
          questionId: oq.questionId._id || oq.questionId,
          sectionCode: oq.sectionCode,
          questionOrder: oq.questionOrder,
          displayOrder: oq.displayOrder,
          marks: oq.marks,
          negativeMarks: oq.negativeMarks,
          isCompulsory: oq.isCompulsory,
          status: oq.status,
        }));
        
        await paperQuestionRepository.bulkCreate(clonedQuestions);
      }
    }

    return newPaper;
  }

  /*
  |--------------------------------------------------------------------------
  | Update Status
  |--------------------------------------------------------------------------
  */

  async updateStatus(id: string, status: PaperStatus) {
    const paper = await super.getById(id);

    return await super.updateStatus(id, status);
  }

  /*
  |--------------------------------------------------------------------------
  | Submit For Approval
  |--------------------------------------------------------------------------
  */

  async submitForApproval(
    id: string,
    payload: { approvalStatus?: string; submittedBy?: string; remarks?: string },
  ) {
    const paper = await super.getById(id);
    const status = (payload.approvalStatus as PaperApprovalStatus) || PaperApprovalStatus.SUBMITTED;

    return await paperRepository.updateApproval(id, status);
  }

  /*
  |--------------------------------------------------------------------------
  | Approve Paper
  |--------------------------------------------------------------------------
  */

  async approvePaper(
    id: string,
    payload: { approvalStatus?: string; approvedBy?: string; approvalRemarks?: string },
  ) {
    const paper = await super.getById(id);
    const status = (payload.approvalStatus as PaperApprovalStatus) || PaperApprovalStatus.APPROVED;

    return await paperRepository.updateApproval(id, status);
  }

  /*
  |--------------------------------------------------------------------------
  | Reject Paper
  |--------------------------------------------------------------------------
  */

  async rejectPaper(
    id: string,
    payload: { approvalStatus?: string; rejectedBy?: string; rejectionReason?: string; rejectionRemarks?: string },
  ) {
    const paper = await super.getById(id);
    const status = (payload.approvalStatus as PaperApprovalStatus) || PaperApprovalStatus.REJECTED;

    return await paperRepository.updateApproval(id, status);
  }

  /*
  |--------------------------------------------------------------------------
  | Update Approval
  |--------------------------------------------------------------------------
  */

  async updateApproval(id: string, approvalStatus: PaperApprovalStatus) {
    const paper = await super.getById(id);

    return await paperRepository.updateApproval(id, approvalStatus);
  }



  /*
  |--------------------------------------------------------------------------
  | Statistics
  |--------------------------------------------------------------------------
  */

  async statistics(companyId?: string) {
    const totalPapers = await paperRepository.count(companyId);

    const activePapers = await paperRepository.countByStatus(
      PaperStatus.ACTIVE,
      companyId,
    );

    const inactivePapers = await paperRepository.countByStatus(
      PaperStatus.INACTIVE,
      companyId,
    );

    const archivedPapers = await paperRepository.countByStatus(
      PaperStatus.ARCHIVED,
      companyId,
    );

    const draftPapers = await paperRepository.countByApproval(
      PaperApprovalStatus.DRAFT,
      companyId,
    );

    const approvedPapers = await paperRepository.countByApproval(
      PaperApprovalStatus.APPROVED,
      companyId,
    );

    const publishedPapers = await paperRepository.countByApproval(
      PaperApprovalStatus.PUBLISHED,
      companyId,
    );

    return {
      totalPapers,
      activePapers,
      inactivePapers,
      archivedPapers,
      draftPapers,
      approvedPapers,
      publishedPapers,
    };
  }
}

export default new PaperService();
