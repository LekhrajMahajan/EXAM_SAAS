import mongoose from "mongoose";
import Admin from "../admin/admin.model";
import Manager from "../manager/manager.model";
import Candidate from "../candidate/candidate.model";
import { IUser } from "./user.types";
import { BaseRepository } from "../../common/base.repository";
import { UserRole } from "../../constants/roles";

class AuthRepository extends BaseRepository<IUser> {
  constructor() {
    super(Admin as any, []);
  }

  private getModelByRole(role: string) {
    if (["MASTER_ADMIN", "COMPANY_ADMIN", "ADMIN"].includes(role)) return Admin;
    if (role === "CANDIDATE") return Candidate;
    return Manager;
  }

  async create(payload: Partial<IUser>, session?: import("mongoose").ClientSession) {
    const Model = this.getModelByRole(payload.role as string);
    const doc = new Model(payload);
    return await doc.save({ session });
  }

  async findByEmail(email: string) {
    let user = await Admin.findOne({ email });
    if (!user) user = await Manager.findOne({ email });
    if (!user) user = await Candidate.findOne({ email });
    return user;
  }

  async findByEmailWithPassword(email: string) {
    let user = await Admin.findOne({ email }).select("+password +refreshToken");
    if (!user) user = await Manager.findOne({ email }).select("+password +refreshToken");
    if (!user) user = await Candidate.findOne({ email }).select("+password +refreshToken");
    return user;
  }

  async findById(id: string, populateFields?: string[]) {
    let user = await Admin.findOne({ _id: id, isDeleted: false });
    if (!user) user = await Manager.findOne({ _id: id, isDeleted: false });
    if (!user) user = await Candidate.findOne({ _id: id, isDeleted: false });
    return user;
  }

  async findByIdWithPassword(id: string) {
    let user = await Admin.findById(id).select("+password +refreshToken");
    if (!user) user = await Manager.findById(id).select("+password +refreshToken");
    if (!user) user = await Candidate.findById(id).select("+password +refreshToken");
    return user;
  }

  async updateRefreshToken(userId: string, refreshToken: string) {
    const options = { new: true };
    let user = await Admin.findByIdAndUpdate(userId, { refreshToken }, options);
    if (!user) user = await Manager.findByIdAndUpdate(userId, { refreshToken }, options);
    if (!user) user = await Candidate.findByIdAndUpdate(userId, { refreshToken }, options);
    return user;
  }

  async updateLastLogin(userId: string) {
    const options = { new: true };
    let user = await Admin.findByIdAndUpdate(userId, { lastLogin: new Date() }, options);
    if (!user) user = await Manager.findByIdAndUpdate(userId, { lastLogin: new Date() }, options);
    if (!user) user = await Candidate.findByIdAndUpdate(userId, { lastLogin: new Date() }, options);
    return user;
  }

  async exists(email: string) {
    return (
      (await Admin.exists({ email })) ||
      (await Manager.exists({ email })) ||
      (await Candidate.exists({ email }))
    );
  }

  async findByRefreshToken(refreshToken: string) {
    let user = await Admin.findOne({ refreshToken }).select("+refreshToken");
    if (!user) user = await Manager.findOne({ refreshToken }).select("+refreshToken");
    if (!user) user = await Candidate.findOne({ refreshToken }).select("+refreshToken");
    return user;
  }

  async clearRefreshToken(userId: string) {
    const options = { new: true };
    let user = await Admin.findByIdAndUpdate(userId, { refreshToken: null }, options);
    if (!user) user = await Manager.findByIdAndUpdate(userId, { refreshToken: null }, options);
    if (!user) user = await Candidate.findByIdAndUpdate(userId, { refreshToken: null }, options);
    return user;
  }

  async addLoginHistory(
    userId: string,
    entry: {
      ipAddress?: string;
      browser?: string;
      operatingSystem?: string;
      location?: string;
      loginAt: Date;
      successful: boolean;
    }
  ) {
    const update = {
      $push: {
        loginHistory: {
          $each: [entry],
          $position: 0,
          $slice: 200,
        },
      },
      ...(entry.successful ? { lastLoginAt: entry.loginAt } : {}),
    };
    const options = { new: true };

    let user = await Admin.findByIdAndUpdate(userId, update, options);
    if (!user) user = await Manager.findByIdAndUpdate(userId, update, options);
    if (!user) user = await Candidate.findByIdAndUpdate(userId, update, options);
    return user;
  }

  async findByEmailOnly(email: string) {
    let user = await Admin.findOne({ email }).select("_id");
    if (!user) user = await Manager.findOne({ email }).select("_id");
    if (!user) user = await Candidate.findOne({ email }).select("_id");
    return user;
  }
}

export default new AuthRepository();
