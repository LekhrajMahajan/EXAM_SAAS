const mongoose = require('mongoose');

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/practice_exam_saas');
  const Admin = require('./src/modules/admin/admin.model').default;
  const Company = require('./src/modules/company/company.model').default;
  
  const admin = await Admin.findOne({ role: 'COMPANY_ADMIN' }).sort({ createdAt: -1 }).select('+password');
  console.log('Latest Company Admin:', admin ? { email: admin.email, status: admin.status, companyId: admin.companyId, passwordHash: admin.password } : 'None');
  
  if (admin) {
     const bcrypt = require('bcryptjs');
     const isMatch = await bcrypt.compare('testpassword', admin.password);
     console.log('Password hash test:', isMatch);
  }
  
  process.exit(0);
}

main().catch(console.error);
