import mongoose from 'mongoose';
import { config } from 'dotenv';
import reportService from './src/modules/report/report.service';

config();

async function test() {
    await mongoose.connect(process.env.MONGODB_URI as string);
    console.log("Connected to DB");
    try {
        const payload = { search: "" };
        const buffer = await reportService.generateCandidateReport(payload, new mongoose.Types.ObjectId().toHexString());
        console.log("Buffer size:", buffer.length);
    } catch (err) {
        console.error("Test failed:", err);
    } finally {
        await mongoose.disconnect();
    }
}
test();
